@echo off
title Blocky Story test render
cd /d "%~dp0"
node render.js %1 --seconds 3
pause
