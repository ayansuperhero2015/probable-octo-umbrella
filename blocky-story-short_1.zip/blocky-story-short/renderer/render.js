// Blocky Story renderer: renders episodes/<ep>/ to episodes/<ep>/final.mp4
// Usage:
//   node render.js <ep>                     full render (GPU via Microsoft Edge on Windows)
//   node render.js <ep> --stills 3,8,22     PNG stills of frame numbers into episodes/<ep>/stills/
//   node render.js <ep> --seconds 3         short test render to episodes/<ep>/test.mp4
// Writes episodes/<ep>/progress.txt while running.
const fs = require('fs');
const path = require('path');
const http = require('http');
const os = require('os');
const { spawn } = require('child_process');

const ROOT = __dirname;
const FPS = 30;
const W = 1080, H = 1920;

const MIME = { '.html': 'text/html', '.js': 'text/javascript', '.mjs': 'text/javascript', '.json': 'application/json',
  '.css': 'text/css', '.woff': 'font/woff', '.woff2': 'font/woff2', '.png': 'image/png', '.jpg': 'image/jpeg',
  '.wav': 'audio/wav', '.glb': 'model/gltf-binary' };

function serve() {
  return new Promise((resolve) => {
    const srv = http.createServer((req, res) => {
      const p = decodeURIComponent(req.url.split('?')[0]);
      const file = path.join(ROOT, p === '/' ? 'index.html' : p);
      if (!file.startsWith(ROOT)) { res.writeHead(403); return res.end(); }
      fs.readFile(file, (err, data) => {
        if (err) { res.writeHead(404); return res.end(); }
        res.writeHead(200, { 'Content-Type': MIME[path.extname(file).toLowerCase()] || 'application/octet-stream' });
        res.end(data);
      });
    });
    srv.listen(0, '127.0.0.1', () => resolve(srv));
  });
}

function ffmpegPath() {
  if (process.env.FFMPEG) return process.env.FFMPEG;
  try { const p = require('ffmpeg-static'); if (p && fs.existsSync(p)) return p; } catch (e) {}
  return 'ffmpeg';
}

async function launch(headless = true) {
  const args = ['--ignore-gpu-blocklist', '--enable-gpu-rasterization', '--enable-zero-copy'];
  if (process.platform === 'win32') args.push('--use-angle=d3d11');
  const errors = [];
  try {
    const { chromium } = require('playwright-core');
    return await chromium.launch({ channel: 'msedge', headless, args: headless ? args : [...args, '--window-position=-4000,0'] });
  } catch (e) { errors.push('msedge: ' + e.message.split('\n')[0]); }
  try {
    const { chromium } = require('playwright-core');
    return await chromium.launch({ channel: 'chrome', headless, args: headless ? args : [...args, '--window-position=-4000,0'] });
  } catch (e) { errors.push('chrome: ' + e.message.split('\n')[0]); }
  try {
    const { chromium } = require('playwright'); // cloud workspace
    return await chromium.launch({ headless: true, args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'] });
  } catch (e) { errors.push('playwright: ' + e.message.split('\n')[0]); }
  throw new Error('No browser found. Tried:\n  ' + errors.join('\n  '));
}

function totalSeconds(epDir) {
  const t = JSON.parse(fs.readFileSync(path.join(epDir, 'timing.json'), 'utf8'));
  if (typeof t.total === 'number') return t.total;
  const segs = Array.isArray(t) ? t : (t.segments || []);
  return Math.max(...segs.map(s => s.end || 0));
}

async function hasGPU(browser) {
  const p = await browser.newPage();
  const r = await p.evaluate(() => { try { const gl = document.createElement('canvas').getContext('webgl'); const e = gl.getExtension('WEBGL_debug_renderer_info'); return e ? gl.getParameter(e.UNMASKED_RENDERER_WEBGL) : ''; } catch (e) { return ''; } });
  await p.close();
  return r && !/swiftshader|llvmpipe|software|basic render/i.test(r);
}

async function render(ep, opts = {}) {
  const epDir = path.join(ROOT, 'episodes', ep);
  if (!fs.existsSync(path.join(epDir, 'engine.js'))) throw new Error(`episodes/${ep}/engine.js not found`);
  const progressFile = path.join(epDir, 'progress.txt');
  const say = (s) => { console.log(s); try { fs.writeFileSync(progressFile, s + '\n'); } catch (e) {} };
  try { os.setPriority(os.constants.priority.PRIORITY_BELOW_NORMAL); } catch (e) {}

  const srv = await serve();
  const port = srv.address().port;
  let browser = await launch(true);
  if (process.platform === 'win32' && !(await hasGPU(browser))) {   // headless didn't get the graphics card: use a hidden off-screen window
    await browser.close().catch(() => {}); browser = await launch(false);
  }
  try {
    const page = await browser.newPage({ viewport: { width: W, height: H }, deviceScaleFactor: 1 });
    page.on('pageerror', e => console.log('page error:', e.message));
    const q = opts.stills ? 'rs=0.6667' : (process.env.Q || 'rs=1&aa=1');   // full res + anti-aliasing for the real render
    await page.goto(`http://127.0.0.1:${port}/index.html?ep=${encodeURIComponent(ep)}&${q}`);
    await page.waitForFunction(() => window.ready || window.engineReady || window.engineError, null, { timeout: 120000 });
    const engineError = await page.evaluate(() => window.engineError);
    if (engineError) throw new Error('engine failed to load: ' + engineError);
    const timing = JSON.parse(fs.readFileSync(path.join(epDir, 'timing.json'), 'utf8'));
    await page.evaluate(t => window.setup ? window.setup(t) : null, timing);

    const gpu = await page.evaluate(() => {
      try {
        const gl = document.createElement('canvas').getContext('webgl');
        const ext = gl.getExtension('WEBGL_debug_renderer_info');
        return ext ? gl.getParameter(ext.UNMASKED_RENDERER_WEBGL) : gl.getParameter(gl.RENDERER);
      } catch (e) { return 'unknown'; }
    });
    const software = /swiftshader|llvmpipe|software|basic render/i.test(gpu);
    console.log('Graphics: ' + gpu + (software ? '  (no graphics card found: software rendering, will be slow)' : ''));
    const hasJPEG = await page.evaluate(() => typeof window.frameJPEG === 'function');
    const grab = async () => {
      if (hasJPEG) { const d = await page.evaluate(t => window.frameJPEG(t), grab.t); return Buffer.from(d.slice(d.indexOf(',') + 1), 'base64'); }
      return page.screenshot({ type: 'jpeg', quality: 92, clip: { x: 0, y: 0, width: W, height: H } });
    };

    if (opts.stills) {
      const dir = path.join(epDir, 'stills'); fs.mkdirSync(dir, { recursive: true });
      for (const f of opts.stills) {
        grab.t = f / FPS;
        const file = path.join(dir, `f${String(f).padStart(5, '0')}.jpg`);
        if (hasJPEG) fs.writeFileSync(file, await grab());
        else { await page.evaluate(t => window.renderAt(t), f / FPS); await page.screenshot({ path: file, type: 'jpeg', quality: 92, clip: { x: 0, y: 0, width: W, height: H } }); }
      }
      say(`stills done: ${opts.stills.length}`);
      return;
    }

    const seconds = opts.seconds || totalSeconds(epDir);
    const frames = Math.round(seconds * FPS);
    const mix = path.join(epDir, 'mix.wav');
    const outName = opts.seconds ? 'test.mp4' : 'final.mp4';
    const tmp = path.join(epDir, outName.replace('.mp4', '.part.mp4'));
    const ffArgs = ['-y', '-loglevel', 'error', '-f', 'image2pipe', '-framerate', String(FPS), '-i', '-'];
    if (fs.existsSync(mix)) ffArgs.push('-i', mix);
    ffArgs.push('-map', '0:v');
    if (fs.existsSync(mix)) ffArgs.push('-map', '1:a', '-c:a', 'aac', '-b:a', '192k');
    ffArgs.push('-c:v', 'libx264', '-preset', 'medium', '-crf', '18', '-pix_fmt', 'yuv420p', '-threads', '2',
      '-t', String(frames / FPS), '-movflags', '+faststart', tmp);
    const ff = spawn(ffmpegPath(), ffArgs, { stdio: ['pipe', 'inherit', 'inherit'] });
    try { os.setPriority(ff.pid, os.constants.priority.PRIORITY_BELOW_NORMAL); } catch (e) {}
    const ffDone = new Promise((res, rej) => { ff.on('close', c => c === 0 ? res() : rej(new Error('ffmpeg exited ' + c))); ff.on('error', rej); });

    const t0 = Date.now();
    for (let i = 0; i < frames; i++) {
      grab.t = i / FPS;
      if (!hasJPEG) await page.evaluate(t => window.renderAt(t), i / FPS);
      const buf = await grab();
      if (!ff.stdin.write(buf)) await new Promise(r => ff.stdin.once('drain', r));
      if (i % 30 === 0 || i === frames - 1) {
        const fps = (i + 1) / ((Date.now() - t0) / 1000);
        const left = Math.round((frames - i - 1) / Math.max(fps, 0.01));
        say(`frame ${i + 1}/${frames}  ${fps.toFixed(1)} fps  ~${Math.floor(left / 60)}m${left % 60}s left  [${gpu}]`);
      }
    }
    ff.stdin.end();
    await ffDone;
    fs.renameSync(tmp, path.join(epDir, outName));
    say(`done: episodes/${ep}/${outName} in ${Math.round((Date.now() - t0) / 1000)}s`);
    return path.join(epDir, outName);
  } finally {
    await browser.close().catch(() => {});
    srv.close();
  }
}

module.exports = { render };

if (require.main === module) {
  const a = process.argv.slice(2);
  let ep = a.find(x => !x.startsWith('--'));
  if (!ep) { // newest episode folder (by timing.json change)
    const base = path.join(ROOT, 'episodes');
    const eps = fs.existsSync(base) ? fs.readdirSync(base).filter(d => fs.existsSync(path.join(base, d, 'timing.json'))) : [];
    eps.sort((x, y) => fs.statSync(path.join(base, y, 'timing.json')).mtimeMs - fs.statSync(path.join(base, x, 'timing.json')).mtimeMs);
    ep = eps[0];
  }
  if (!ep) { console.error('No episode folder found in episodes/'); process.exit(1); }
  const opts = {};
  const si = a.indexOf('--stills'); if (si >= 0) opts.stills = a[si + 1].split(',').map(Number);
  const se = a.indexOf('--seconds'); if (se >= 0) opts.seconds = Number(a[se + 1]);
  render(ep, opts).catch(e => { console.error('RENDER FAILED: ' + e.message); try { fs.writeFileSync(path.join(ROOT, 'episodes', ep, 'error.txt'), e.stack || String(e)); } catch (_) {} process.exit(1); });
}
