// Called by setup.bat: makes the render watcher start hidden at every Windows login, and starts it now.
const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');

const ROOT = __dirname;
const startup = path.join(process.env.APPDATA || '', 'Microsoft', 'Windows', 'Start Menu', 'Programs', 'Startup');
const vbsPath = path.join(startup, 'blocky-story-render-watcher.vbs');
const nodeExe = process.execPath;

const vbStr = (s) => '"' + s.replace(/"/g, '""') + '"';
const cmd = `cmd /c ""${nodeExe}" watcher.js >> watcher.log 2>&1"`;
const vbs = [
  'Set sh = CreateObject("WScript.Shell")',
  `sh.CurrentDirectory = ${vbStr(ROOT)}`,
  `sh.Run ${vbStr(cmd)}, 0, False`,
  ''
].join('\r\n');

fs.mkdirSync(startup, { recursive: true });
fs.writeFileSync(vbsPath, vbs);
console.log('Auto-start installed: ' + vbsPath);
spawn('wscript.exe', [vbsPath], { detached: true, stdio: 'ignore' }).unref();
console.log('Render watcher started in the background.');
