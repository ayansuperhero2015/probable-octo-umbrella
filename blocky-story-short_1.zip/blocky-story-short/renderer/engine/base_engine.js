// Blocky Story base engine: the reusable library for every episode.
// Copy to episodes/<ep>/engine.js, then edit ONLY the sections marked "PER EPISODE":
//   CAST (the channel's characters, from channel_profile.md), SETS (locations for this story),
//   HL (caption keyword colours), TITLE (hook title) and the shot{} object (one function per segment id).
// The two example sets and the example shots below are placeholders to show the patterns: replace them.
//
// Contract with render.js / index.html:
//   window.setup(timing)  -> called once with timing.json; window.frameJPEG(t) -> data URL of the composited frame;
//   window.renderAt(t) draws frame t; window.ready = true when loaded.
// timing.json: { total, segments: [ { id, part, text, start, end, words: [ { w, s, e, q } ] } ] }
//   w = word as written in the script, s/e = start/end seconds, q = true if the word is inside "quotes" (spoken dialogue: mouth flaps).
import * as THREE from 'three';
import { RoundedBoxGeometry } from 'three/addons/geometries/RoundedBoxGeometry.js';

const W = 1080, H = 1920;
const renderer = new THREE.WebGLRenderer({ canvas: document.getElementById('c'), antialias: !!window.AA, preserveDrawingBuffer: true });
const RS = window.RSCALE || (2/3); renderer.setSize(Math.round(W*RS), Math.round(H*RS), false);
renderer.setPixelRatio(1);
renderer.shadowMap.enabled = !window.NOSH;
renderer.shadowMap.type = THREE.PCFShadowMap;
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.05;

const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(50, W / H, 0.1, 900);
camera.layers.enable(1);
scene.add(camera);
const fill = new THREE.DirectionalLight('#ffffff', 1); fill.position.set(.4, .5, 1); camera.add(fill); fill.target.position.set(0, 0, -5); camera.add(fill.target);

// ---------- helpers ----------
const lerp = (a, b, t) => a + (b - a) * t;
const clamp = (x, a = 0, b = 1) => Math.max(a, Math.min(b, x));
const ease = t => { t = clamp(t); return t < .5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2; };
const easeOut = t => 1 - Math.pow(1 - clamp(t), 3);
const V = (x, y, z) => new THREE.Vector3(x, y, z);
const geoCache = {};
function rgeo(w, h, d, r = 0.12) {
  const k = [w, h, d, r].join();
  if (!geoCache[k]) geoCache[k] = new RoundedBoxGeometry(w, h, d, window.SEG || 2, Math.min(r, w / 2.2, h / 2.2, d / 2.2));
  return geoCache[k];
}
const matCache = {};
function mat(color, opts = {}) {
  const k = color + JSON.stringify(opts);
  if (!matCache[k]) matCache[k] = new THREE.MeshStandardMaterial({ color, roughness: 0.75, metalness: 0.0, ...opts });
  return matCache[k];
}
function box(w, h, d, color, x = 0, y = 0, z = 0, opts = {}, r = 0.08) {
  const m = new THREE.Mesh(rgeo(w, h, d, r), opts.isMaterial ? opts : mat(color, opts));
  m.position.set(x, y, z); m.castShadow = true; m.receiveShadow = true; return m;
}
function canvasTex(w, h, draw) {
  const c = document.createElement('canvas'); c.width = w; c.height = h;
  draw(c.getContext('2d'), w, h);
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 4; return t;
}
let seed = 7; const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647;
function at(m, x, y, z) { m.position.set(x, y, z); return m; }
function rr(g, x, y, w, h, r) { g.beginPath(); g.moveTo(x + r, y); g.arcTo(x + w, y, x + w, y + h, r); g.arcTo(x + w, y + h, x, y + h, r); g.arcTo(x, y + h, x, y, r); g.arcTo(x, y, x + w, y, r); g.closePath(); }
function setLayer(obj, n) { obj.traverse(o => o.layers.set(n)); }

// ---------- faces ----------
const faceCache = {};
function faceTex(expr, open = false) {
  const key = expr + open;
  if (faceCache[key]) return faceCache[key];
  const t = canvasTex(256, 256, (g) => {
    g.lineCap = 'round'; g.lineJoin = 'round';
    const ink = '#161616';
    const eye = (x, y, w = 24, h = 44) => { g.fillStyle = ink; rr(g, x - w / 2, y - h / 2, w, h, w / 2); g.fill(); g.fillStyle = '#fff'; g.beginPath(); g.arc(x - 4, y - 10, 6, 0, 7); g.fill(); };
    const lineEye = (x, y, up = true) => { g.strokeStyle = ink; g.lineWidth = 10; g.beginPath(); up ? g.arc(x, y + 8, 18, Math.PI * 1.15, Math.PI * 1.85) : g.arc(x, y - 6, 18, Math.PI * .15, Math.PI * .85); g.stroke(); };
    const brow = (x, y, ang) => { g.save(); g.translate(x, y); g.rotate(ang); g.fillStyle = ink; rr(g, -24, -6, 48, 12, 6); g.fill(); g.restore(); };
    const mouthSmile = () => { g.strokeStyle = ink; g.lineWidth = 11; g.beginPath(); g.arc(128, 150, 42, Math.PI * .18, Math.PI * .82); g.stroke(); };
    const mouthOpen = (w = 46, h = 34, y = 178) => { g.fillStyle = ink; g.beginPath(); g.ellipse(128, y, w, h, 0, 0, 7); g.fill(); g.fillStyle = '#e0505a'; g.beginPath(); g.ellipse(128, y + h * .45, w * .55, h * .35, 0, 0, 7); g.fill(); };
    const mouthFlat = () => { g.fillStyle = ink; rr(g, 98, 176, 60, 11, 5); g.fill(); };
    const mouthSad = () => { g.strokeStyle = ink; g.lineWidth = 11; g.beginPath(); g.arc(128, 215, 36, Math.PI * 1.2, Math.PI * 1.8); g.stroke(); };
    const tear = (x, y) => { g.fillStyle = '#7fd0ff'; g.beginPath(); g.ellipse(x, y, 9, 14, 0, 0, 7); g.fill(); };
    switch (expr) {
      case 'smile': eye(88, 112); eye(168, 112); open ? mouthOpen(40, 28, 172) : mouthSmile(); break;
      case 'neutral': eye(88, 112); eye(168, 112); open ? mouthOpen(34, 24) : mouthFlat(); break;
      case 'shout': brow(88, 72, .35); brow(168, 72, -.35); eye(88, 112, 24, 36); eye(168, 112, 24, 36); mouthOpen(56, open ? 48 : 40, 182); break;
      case 'happyclosed': lineEye(88, 112, true); lineEye(168, 112, true); open ? mouthOpen(42, 30, 172) : mouthSmile(); break;
      case 'closed': lineEye(88, 116, false); lineEye(168, 116, false); g.fillStyle = ink; g.beginPath(); g.ellipse(128, 182, 10, 7, 0, 0, 7); g.fill(); break;
      case 'squeeze': { // eyes squeezed shut
        g.strokeStyle = ink; g.lineWidth = 10;
        for (const [x, s] of [[88, 1], [168, -1]]) { g.beginPath(); g.moveTo(x - 22 * s, 100); g.lineTo(x + 18 * s, 114); g.lineTo(x - 22 * s, 128); g.stroke(); }
        brow(88, 78, -.35); brow(168, 78, .35);
        g.strokeStyle = ink; g.lineWidth = 9; g.beginPath(); for (let i = 0; i <= 6; i++) g.lineTo(96 + i * 11, 184 + (i % 2 ? -7 : 7)); g.stroke(); break; }
      case 'scared': {
        for (const x of [88, 168]) { g.fillStyle = '#fff'; g.beginPath(); g.arc(x, 110, 26, 0, 7); g.fill(); g.strokeStyle = ink; g.lineWidth = 6; g.stroke(); g.fillStyle = ink; g.beginPath(); g.arc(x, 112, 8, 0, 7); g.fill(); }
        brow(88, 66, -.3); brow(168, 66, .3);
        if (open) mouthOpen(30, 34, 184); else { g.strokeStyle = ink; g.lineWidth = 9; g.beginPath(); for (let i = 0; i <= 6; i++) g.lineTo(96 + i * 11, 184 + (i % 2 ? -8 : 8)); g.stroke(); }
        break; }
      case 'shock': {
        for (const x of [88, 168]) { g.fillStyle = '#fff'; g.beginPath(); g.arc(x, 108, 28, 0, 7); g.fill(); g.strokeStyle = ink; g.lineWidth = 6; g.stroke(); g.fillStyle = ink; g.beginPath(); g.arc(x, 108, 9, 0, 7); g.fill(); }
        brow(88, 62, -.15); brow(168, 62, .15); mouthOpen(26, open ? 36 : 30, 186); break; }
      case 'worried': brow(88, 74, -.35); brow(168, 74, .35); eye(88, 116, 22, 38); eye(168, 116, 22, 38); open ? mouthOpen(28, 24, 184) : (g.fillStyle = ink, g.beginPath(), g.ellipse(128, 184, 14, 12, 0, 0, 7), g.fill()); break;
      case 'sad': brow(88, 76, -.3); brow(168, 76, .3); eye(88, 118, 22, 34); eye(168, 118, 22, 34); open ? mouthOpen(30, 22, 188) : mouthSad(); break;
      case 'angry': brow(88, 78, .45); brow(168, 78, -.45); eye(88, 116, 22, 30); eye(168, 116, 22, 30); open ? mouthOpen(40, 30, 184) : mouthSad(); break;
      case 'smirk': {
        brow(88, 80, .25); brow(168, 72, -.1);
        for (const x of [88, 168]) { g.fillStyle = ink; rr(g, x - 13, 106, 26, 26, 12); g.fill(); g.fillStyle = '#f2c69a'; g.fillRect(x - 16, 100, 32, 12); g.strokeStyle = ink; g.lineWidth = 7; g.beginPath(); g.moveTo(x - 16, 108); g.lineTo(x + 16, 108); g.stroke(); }
        if (open) mouthOpen(34, 24, 176);
        else { g.strokeStyle = ink; g.lineWidth = 11; g.beginPath(); g.moveTo(96, 176); g.quadraticCurveTo(140, 186, 172, 156); g.stroke(); }
        break; }
      case 'grin': { // creepy wide grin
        for (const x of [88, 168]) { g.fillStyle = ink; rr(g, x - 14, 100, 28, 28, 13); g.fill(); g.fillStyle = '#fff'; g.beginPath(); g.arc(x - 3, 108, 4, 0, 7); g.fill(); }
        brow(88, 78, .35); brow(168, 78, -.35);
        g.fillStyle = ink; g.beginPath(); g.moveTo(60, 150); g.quadraticCurveTo(128, 230, 196, 150); g.quadraticCurveTo(128, 186, 60, 150); g.fill();
        g.fillStyle = '#fff'; for (let i = 0; i < 6; i++) { g.fillRect(80 + i * 17, 160 + Math.abs(i - 2.5) * -3, 12, 12); }
        break; }
      case 'sus': {
        for (const x of [88, 168]) { g.fillStyle = ink; rr(g, x - 16, 108, 32, 16, 8); g.fill(); }
        brow(88, 92, .2); brow(168, 92, -.2); open ? mouthOpen(28, 20, 182) : mouthFlat(); break; }
      case 'cold': { // flat stare (stopped smiling)
        for (const x of [88, 168]) { g.fillStyle = ink; rr(g, x - 13, 102, 26, 30, 12); g.fill(); }
        mouthFlat(); break; }
      case 'cry': brow(88, 74, -.4); brow(168, 74, .4); eye(88, 116, 22, 30); eye(168, 116, 22, 30); open ? mouthOpen(30, 22, 190) : mouthSad(); tear(70, 150); tear(186, 150); tear(66, 184); tear(190, 184); break;
      case 'blank': break;
    }
  });
  faceCache[key] = t; return t;
}


// ---------- avatar ----------
function avatar(o) {
  const g = new THREE.Group();
  const body = new THREE.Group(); g.add(body);
  const parts = {};
  const M = c => o.own ? new THREE.MeshStandardMaterial({ color: c, roughness: .75, transparent: true }) : mat(c);
  const torso = new THREE.Mesh(rgeo(2, 2, 1, .14), M(o.shirt)); torso.position.y = 3; body.add(torso); parts.torso = torso;
  const headG = new THREE.Group(); headG.position.y = 4; body.add(headG);
  const head = new THREE.Mesh(rgeo(1.25, 1.25, 1.25, .28), M(o.skin)); head.position.y = .66; headG.add(head);
  const faceMat = new THREE.MeshBasicMaterial({ map: faceTex(o.face || 'smile'), transparent: true, depthWrite: false });
  const face = new THREE.Mesh(new THREE.PlaneGeometry(1.15, 1.15), faceMat); face.position.set(0, .66, .64); headG.add(face);
  const hc = o.hair;
  if (o.hairStyle === 'messy') {
    headG.add(box(1.35, .35, 1.35, hc, 0, 1.35, 0, {}, .1));
    for (const [x, z, h] of [[-.45, .4, .5], [0, .5, .6], [.45, .35, .45], [-.4, -.3, .5], [.35, -.4, .55], [0, -.1, .7]]) headG.add(box(.45, h, .45, hc, x, 1.45 + h / 4, z, {}, .08));
    headG.add(box(1.35, .5, .25, hc, 0, 1.05, -.6, {}, .08));
    headG.add(box(.5, .3, .2, hc, -.35, 1.18, .62, {}, .06));
  } else if (o.hairStyle === 'swoop') {
    headG.add(box(1.38, .4, 1.38, hc, 0, 1.36, 0, {}, .12));
    headG.add(box(1.0, .35, .35, hc, .15, 1.2, .62, {}, .1));
    headG.add(box(1.38, .7, .3, hc, 0, .95, -.6, {}, .08));
  } else if (o.hairStyle === 'long') {
    headG.add(box(1.42, .4, 1.42, hc, 0, 1.36, 0, {}, .14));
    headG.add(box(1.45, 1.7, .4, hc, 0, .55, -.58, {}, .12));
    headG.add(box(.3, 1.5, 1.1, hc, -.7, .55, -.1, {}, .1));
    headG.add(box(.3, 1.5, 1.1, hc, .7, .55, -.1, {}, .1));
  } else if (o.hairStyle === 'bun') {
    headG.add(box(1.4, .38, 1.4, hc, 0, 1.36, 0, {}, .14));
    headG.add(box(.7, .6, .7, hc, 0, 1.75, -.25, {}, .25));
    headG.add(box(1.4, .8, .3, hc, 0, .95, -.6, {}, .08));
  } else if (o.hairStyle === 'cap') {
    headG.add(box(1.38, .42, 1.38, hc, 0, 1.36, 0, {}, .14));
    headG.add(box(1.2, .1, .6, hc, 0, 1.2, .85, {}, .04));
  }
  const limb = (x, y, top, bottom, isArm) => {
    const pv = new THREE.Group(); pv.position.set(x, y, 0); body.add(pv);
    if (isArm) { pv.add(at(new THREE.Mesh(rgeo(.98, .95, .98, .12), M(top)), 0, -.5, 0)); pv.add(at(new THREE.Mesh(rgeo(.96, 1.1, .96, .14), M(bottom)), 0, -1.45, 0)); }
    else { pv.add(at(new THREE.Mesh(rgeo(.98, 1.7, .98, .12), M(top)), 0, -.85, 0)); pv.add(at(new THREE.Mesh(rgeo(1.0, .35, 1.08, .1), M(bottom)), 0, -1.82, .04)); }
    return pv;
  };
  parts.armL = limb(-1.5, 3.95, o.sleeve || o.shirt, o.skin, true);
  parts.armR = limb(1.5, 3.95, o.sleeve || o.shirt, o.skin, true);
  parts.legL = limb(-.5, 2, o.pants, o.shoes || '#2a2a2a', false);
  parts.legR = limb(.5, 2, o.pants, o.shoes || '#2a2a2a', false);
  // wrist watch (left by default, right for the fake)
  if (o.watch) {
    const arm = o.watch === 'R' ? parts.armR : parts.armL, sx = o.watch === 'R' ? 1 : -1;
    const w = new THREE.Group(); w.add(box(1.04, .26, 1.04, '#1c1c24', 0, 0, 0, {}, .05));
    w.add(box(.08, .42, .42, '#d8d8e0', sx * .54, 0, 0, {}, .03));
    w.add(box(.04, .32, .32, '#ffd34a', sx * .58, 0, 0, { emissive: '#806000', emissiveIntensity: .4 }, .02));
    w.position.y = -1.62; arm.add(w);
  }
  // hidden hand-held prop slot (e.g. a phone): fill A.brush with meshes and toggle A.brush.visible
  const brush = new THREE.Group(); brush.position.set(0, -2.0, .35); brush.visible = false; parts.armL.add(brush);
  g.traverse(m => { if (m.isMesh && m !== face) { m.castShadow = true; m.receiveShadow = true; } });
  face.castShadow = false;
  const A = { g, body, headG, face, faceMat, parts, o, brush, expr: o.face || 'smile', open: false, sc: o.scale || 1, lastP: {} };
  A.setFace = (e, open = false) => { if (A.expr !== e || A.open !== open) { A.expr = e; A.open = open; faceMat.map = faceTex(e, open); faceMat.needsUpdate = true; } };
  A.pose = (p = {}) => {
    A.lastP = p;
    parts.armL.rotation.set(p.aLx || 0, p.aLy || 0, p.aLz || 0); parts.armR.rotation.set(p.aRx || 0, p.aRy || 0, p.aRz || 0);
    parts.legL.rotation.set(p.lLx || 0, 0, p.lLz || 0); parts.legR.rotation.set(p.lRx || 0, 0, p.lRz || 0);
    headG.rotation.set(p.hx || 0, p.hy || 0, p.hz || 0);
    body.rotation.set(p.bx || 0, p.by || 0, p.bz || 0); body.position.set(p.px || 0, p.bob || 0, p.pz || 0);
  };
  A.fade = (names, op) => names.forEach(n => { const p = parts[n]; p.visible = op > .01; p.traverse(m => { if (m.isMesh) { m.material.opacity = op; m.castShadow = op > .5; } }); });
  return A;
}
const P = {
  idle: (t, k = 1) => ({ bob: Math.sin(t * 2.2) * .04 * k, aLz: -.06 - Math.sin(t * 2.2) * .03, aRz: .06 + Math.sin(t * 2.2) * .03, hx: Math.sin(t * 1.3) * .03 }),
  walk: (t, s = 6) => { const a = Math.sin(t * s) * .7; return { aLx: a, aRx: -a, lLx: -a, lRx: a, bob: Math.abs(Math.cos(t * s)) * .15 }; },
  run: (t, s = 12) => { const a = Math.sin(t * s) * 1.1; return { aLx: a, aRx: -a, lLx: -a * .9, lRx: a * .9, bob: Math.abs(Math.cos(t * s)) * .35, bx: .18 }; },
  talk: (t, k = 1) => ({ bob: Math.sin(t * 2.2) * .04, aRx: -.3 * k + Math.sin(t * 5) * .15 * k, aRz: .15, aLz: -.08, hx: Math.sin(t * 7) * .04, hz: Math.sin(t * 3) * .04 }),
  shout: (t) => ({ aLx: -1.2 + Math.sin(t * 9) * .2, aRx: -1.2 - Math.sin(t * 9) * .2, aLz: -.5, aRz: .5, hx: -.15 + Math.sin(t * 14) * .05, bob: Math.abs(Math.sin(t * 9)) * .1 }),
  cheer: (t) => ({ aLz: -2.6 + Math.sin(t * 9) * .25, aRz: 2.6 - Math.sin(t * 9) * .25, bob: Math.abs(Math.sin(t * 7)) * .5, hx: -.15 }),
  wave: (t, ph = 0) => ({ aRz: 2.35 + Math.sin(t * 7 + ph) * .45, aLz: -.08, bob: Math.sin(t * 2.2 + ph) * .04, hz: Math.sin(t * 3.5 + ph) * .08 }),
  laugh: (t) => ({ bob: Math.abs(Math.sin(t * 9)) * .08, bx: .08 + Math.sin(t * 9) * .04, aLz: -.15, aRx: -1.2, aRz: .35 }),
  hairTouch: (t) => ({ aRx: -2.7, aRz: -.35, aLz: -.08, hx: .05, bob: Math.sin(t * 2) * .02 }),
  lean: (t, k = 1) => ({ bx: .3 * k, hx: -.1 * k, aLz: -.1, aRz: .1, bob: Math.sin(t * 2) * .02 }),
  cross: (t) => ({ aLx: -1.25, aLz: .75, aRx: -1.15, aRz: -.75, bob: Math.sin(t * 2) * .02, hx: Math.sin(t * 1.3) * .03 }),
  brush: (t) => ({ aRx: -2.1 + Math.sin(t * 16) * .12, aRz: -.55, aRy: .2, aLz: -.06, bob: Math.sin(t * 2) * .02 }),
  catch: (t, k) => ({ aRx: lerp(-2.1, -.9, k), aRz: lerp(-.55, -.1, k), aLz: -.06, bx: .12 * k, hx: .3 * k }),
  press: (t, k = 1) => ({ aLx: -1.75 * k, aRx: -1.75 * k, aLz: -.32 * k, aRz: .32 * k, bob: Math.sin(t * 2) * .02, bx: .06 * k }),
  pound: (t) => { const a = Math.abs(Math.sin(t * 7)), b = Math.abs(Math.sin(t * 7 + 1.6)); return { aLx: -2.0 + a * .55, aRx: -2.0 + b * .55, aLz: -.25, aRz: .25, bx: .08, hx: -.1 + Math.sin(t * 14) * .04 }; },
  reach: (t, k) => ({ aLx: -2.7 * k, aRx: -2.7 * k, aLz: .1 * k, aRz: -.1 * k, bob: .1 * k }),
  throw: (t, ph = 0) => { const c = ((t + ph) % 1.4) / 1.4; const s = c < .5 ? lerp(.6, -2.6, ease(c * 2)) : lerp(-2.6, .6, ease((c - .5) * 2)); return { aRx: s, aRz: .2, aLx: -.4, aLz: -.1, bx: c < .5 ? -.1 + c * .4 : .1, bob: Math.sin(t * 3) * .03 }; },
  duck: (t, k) => ({ bx: .55 * k, bob: -.75 * k, lLx: -1.05 * k, lRx: -1.05 * k, aLx: -2.6 * k, aRx: -2.6 * k, aLz: .3 * k, aRz: -.3 * k, hx: .2 * k }),
  fall: (t, k) => ({ bx: -1.42 * k, bob: .5 * k, lLx: -.8 * k, lRx: -.4 * k, aLz: -1.6 * k, aRz: 1.6 * k, hx: -.2 * k }),
  hop: (t, k) => ({ aLz: -1.1 * Math.sin(Math.PI * k), aRz: 1.1 * Math.sin(Math.PI * k), lLx: -.5 * Math.sin(Math.PI * k), lRx: .3 * Math.sin(Math.PI * k), bx: -.2 * Math.sin(Math.PI * k) }),
  grab: (t) => ({ aRx: -1.45, aRz: -.25, aLz: -.1, bx: .1, bob: Math.sin(t * 2) * .02 }),
  around: (t) => ({ aRz: 1.75, aRx: -.55, aLz: -.08, bob: Math.sin(t * 2.2) * .03, hz: .08 }),
  check: (t) => ({ aLx: -1.45, aLz: .75, aLy: .3, aRz: .08, hx: .35, hy: -.25, bob: Math.sin(t * 2) * .02 }),
  armlook: (t) => ({ aRz: .08, aLz: -.06, hy: -.55, hx: .35, bob: Math.sin(t * 2) * .02 }),
  back: (t) => ({ aLx: -.5, aRx: -.5, aLz: -.3, aRz: .3, bx: -.12, bob: Math.sin(t * 2) * .02 }),
  hug: (t) => ({ aLx: -1.35, aRx: -1.35, aLz: .2, aRz: -.2, bx: .1, hx: .05, hz: .1, bob: Math.sin(t * 2) * .02 }),
};
const face2 = (x, z, tx, tz) => Math.atan2(tx - x, tz - z);

// ---------- sets ----------
const sets = {};
function mkSet(name, x, z) { const g = new THREE.Group(); g.position.set(x, 0, z); g.visible = false; scene.add(g); sets[name] = g; return g; }
function sky(top, bottom, clouds = true) { return canvasTex(512, 1024, (g, w, h) => { const gr = g.createLinearGradient(0, 0, 0, h); gr.addColorStop(0, top); gr.addColorStop(1, bottom); g.fillStyle = gr; g.fillRect(0, 0, w, h); if (!clouds) return; g.fillStyle = 'rgba(255,255,255,.85)'; for (const [x, y, s] of [[90, 260, 1], [360, 180, 1.3], [250, 420, .8]]) { for (const [dx, dy, r] of [[0, 0, 40], [40, -14, 46], [84, 0, 38], [40, 12, 40]]) { g.beginPath(); g.arc(x + dx * s, y + dy * s, r * s, 0, 7); g.fill(); } } }); }
const daySky = sky('#3e8ef0', '#bfe6ff');
const studTex = (c1) => { const t = canvasTex(64, 64, (g) => { g.fillStyle = c1; g.fillRect(0, 0, 64, 64); g.fillStyle = 'rgba(255,255,255,.07)'; g.beginPath(); g.arc(32, 32, 14, 0, 7); g.fill(); g.fillStyle = 'rgba(0,0,0,.10)'; g.beginPath(); g.arc(33, 35, 14, 0, 7); g.fill(); g.fillStyle = c1; g.beginPath(); g.arc(32, 32, 12, 0, 7); g.fill(); g.strokeStyle = 'rgba(0,0,0,.06)'; g.strokeRect(0, 0, 64, 64); }); t.wrapS = t.wrapT = THREE.RepeatWrapping; return t; };
const tileTex = (c1, c2) => { const t = canvasTex(64, 64, (g) => { g.fillStyle = c2; g.fillRect(0, 0, 64, 64); g.fillStyle = c1; g.fillRect(2, 2, 60, 60); }); t.wrapS = t.wrapT = THREE.RepeatWrapping; return t; };
function ground(set, w, d, color, rep = 1, x = 0, z = 0, tex) { const t = tex || studTex(color); t.repeat.set(w / 2 * rep, d / 2 * rep); const m = new THREE.Mesh(new THREE.PlaneGeometry(w, d), new THREE.MeshStandardMaterial({ map: t, roughness: .9 })); m.rotation.x = -Math.PI / 2; m.position.set(x, 0, z); m.receiveShadow = true; set.add(m); return m; }
function sun(set, pos, target, intensity = 2.6, color = '#fff2dd', size = 40) {
  const d = new THREE.DirectionalLight(color, intensity); d.position.copy(pos); d.target.position.copy(target); set.add(d); set.add(d.target);
  d.castShadow = true; d.shadow.mapSize.set(1024, 1024); const c = d.shadow.camera; c.left = -size; c.right = size; c.top = size; c.bottom = -size; c.near = 1; c.far = 200; d.shadow.bias = -0.0008; d.shadow.normalBias = .04; c.layers.enable(1); return d;
}
function signTex(text, bg, fg, w = 512, h = 128, size = 80) { return canvasTex(w, h, (g) => { g.fillStyle = bg; g.fillRect(0, 0, w, h); g.fillStyle = fg; g.font = `bold ${size}px Arial`; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(text, w / 2, h / 2 + 4); }); }
function plane(w, h, m, x, y, z, ry = 0) { const p = new THREE.Mesh(new THREE.PlaneGeometry(w, h), m); p.position.set(x, y, z); p.rotation.y = ry; return p; }

// ---------- CAST (PER EPISODE: build from channel_profile.md) ----------
// avatar options: skin, shirt, sleeve, pants, shoes, hair, hairStyle (messy|swoop|long|bun|cap|none), face, scale (kids ~.62-.72), watch ('L'|'R')
const SKIN = '#f2c69a';
const lead = avatar({ skin: SKIN, shirt: '#e0603a', pants: '#2e3440', shoes: '#ffffff', hair: '#4a2c18', hairStyle: 'cap', face: 'smile' });
const side = avatar({ skin: '#c68b5e', shirt: '#8a5ad6', pants: '#3a3a4a', shoes: '#222222', hair: '#1a1a1a', hairStyle: 'long', face: 'smile' });
const all = [lead, side];
all.forEach(a => scene.add(a.g));
const KID = .68;

const props = [];
function prop(g) { scene.add(g); props.push(g); return g; }
const pop = k => { k = clamp(k); const c1 = 1.70158, c3 = c1 + 1; return 1 + c3 * Math.pow(k - 1, 3) + c1 * Math.pow(k - 1, 2); };

// ---------- effects ----------
function mkBurst(n = 10) { const G = new THREE.Group(); G.bits = []; for (let i = 0; i < n; i++) { const m = new THREE.Mesh(new THREE.SphereGeometry(.5, 8, 6), new THREE.MeshBasicMaterial({ color: '#fff', transparent: true, depthWrite: false })); const a = i / n * Math.PI * 2, e = (rnd() - .3) * 1.4; m.dir = V(Math.cos(a) * Math.cos(e), Math.sin(e) + .2, Math.sin(a) * Math.cos(e)); G.add(m); G.bits.push(m); } return prop(G); }
const fx = [mkBurst(), mkBurst(), mkBurst()];
function burst(i, s, x, y, z, k, size = 2, col = '#ffffff', bit = 1) { if (k <= 0 || k >= 1) return; const G = fx[i]; G.visible = true; G.position.set(s.position.x + x, y, s.position.z + z); const e = easeOut(k); G.bits.forEach(m => { m.position.copy(m.dir).multiplyScalar(e * size); m.scale.setScalar(bit * (1 - k * .8)); m.material.color.set(col); m.material.opacity = 1 - k; }); }

// ---------- SETS (PER EPISODE: build the locations this story needs, in the channel's vibe) ----------
// Each set is a group far from the others (mkSet(name, x, z)); only one is visible per shot.
// Keep lights bright (dark frames look broken on phones). Keep cameras outside solid boxes.
{
  const s = mkSet('park', 0, 0);
  ground(s, 120, 120, '#5cbf4a', .5);
  s.add(new THREE.HemisphereLight('#ffffff', '#6a8a5a', 1.1));
  sun(s, V(20, 40, 25), V(0, 0, 0), 2.4);
  for (const [x, z] of [[-9, -8], [8, -10], [-14, 4], [13, 3]]) { s.add(box(1, 4, 1, '#7a4a2a', x, 2, z)); s.add(box(4, 3.5, 4, '#3fa04a', x, 5.4, z, {}, .5)); }
  s.add(box(6, .6, 2, '#c8743a', 0, 1.6, -4)); s.add(box(6, 1.4, .4, '#c8743a', 0, 2.6, -4.9));   // bench
  for (const x of [-2.4, 2.4]) s.add(box(.4, 1.3, 1.6, '#555', x, .65, -4));
}
{
  const s = mkSet('room', 400, 0);
  ground(s, 22, 16, '#c9a27a', 1, 0, 0, tileTex('#d8b48a', '#b08a62'));
  s.add(box(22, 12, .6, '#9fd0e8', 0, 6, -8)); s.add(box(.6, 12, 16, '#8cc4de', -11, 6, 0)); s.add(box(.6, 12, 16, '#8cc4de', 11, 6, 0));
  s.add(new THREE.HemisphereLight('#ffffff', '#806040', 1.1));
  const pl = new THREE.PointLight('#fff2dd', 60, 40); pl.position.set(0, 10, 2); s.add(pl);
  s.add(box(6, 1.2, 3.4, '#e05050', -6, .9, -5.5)); s.add(box(6, .8, 3.4, '#ffffff', -6, 1.8, -5.5));   // bed
}


// ---------- per-frame scene control ----------
function showOnly(...names) { for (const k in sets) sets[k].visible = names.includes(k); }
function hideAll() { all.forEach(a => { a.g.visible = false; a.g.scale.setScalar(a.sc); a.g.rotation.set(0, 0, 0); a.pose({}); a.brush.visible = false; }); props.forEach(p => p.visible = false); }
function place(A, set, x, y, z, ry = 0) { A.g.visible = true; A.g.position.set(set.position.x + x, y, set.position.z + z); A.g.rotation.set(0, ry, 0); }
let camShake = 0;
function cam(set, p0, p1, l0, l1, u, fov = 50) {
  const o = set.position; const e = ease(u);
  camera.position.set(o.x + lerp(p0[0], p1[0], e), lerp(p0[1], p1[1], e), o.z + lerp(p0[2], p1[2], e));
  camera.lookAt(o.x + lerp(l0[0], l1[0], e), lerp(l0[1], l1[1], e), o.z + lerp(l0[2], l1[2], e));
  if (camShake > 0) { camera.position.x += (Math.sin(T * 91) + Math.sin(T * 37)) * camShake * .5; camera.position.y += (Math.sin(T * 73) + Math.cos(T * 29)) * camShake * .5; }
  camera.fov = fov; camera.updateProjectionMatrix();
}
let T = 0;
const bg = c => { scene.background = c instanceof THREE.Texture ? c : new THREE.Color(c); };
function tag(text, x, y, op = 1, cls = 'y') { tagEl.style.opacity = op; tagEl.style.left = x + 'px'; tagEl.style.top = y + 'px'; tagEl.textContent = text; tagEl.dataset.cls = cls; }
function tint(c, o) { tintEl.style.background = c; tintEl.style.opacity = o; }
function flash(c, o) { fadeEl.style.background = c; fadeEl.style.opacity = clamp(o); }
const LIMBS = ['armL', 'armR', 'legL', 'legR', 'torso'];
function resetAll() {   // PER EPISODE: reset props / lights you change inside shots
  all.forEach(A => A.setFace('neutral')); camShake = 0;
}
function inSet(n, b) { showOnly(n); bg(b); hideAll(); resetAll(); return sets[n]; }
function wp(A, part, x, y, z, s) { A.g.updateMatrixWorld(true); const v = part.localToWorld(V(x, y, z)); return [v.x - s.position.x, v.y, v.z - s.position.z]; }
let FILL = .7;
function ots(s, ax, az, bx, bz, u, o = {}) {
  const back = o.back ?? 2.6, side = o.side ?? 2.1, y = o.y ?? 6.0, ly = o.ly ?? 4.8, push = o.push ?? .5;
  let dx = ax - bx, dz = az - bz; const L = Math.hypot(dx, dz); dx /= L; dz /= L; const px = dz, pz = -dx;
  cam(s, [ax + dx * back + px * side, y, az + dz * back + pz * side], [ax + dx * (back - push) + px * side, y - .05, az + dz * (back - push) + pz * side], [bx, ly, bz], [bx, ly, bz], u, o.fov ?? 44);
}
// face close-up: camera in front of the avatar (ang = how far round to the side), face sits in the upper half
function closeUp(s, A, u, o = {}) {
  const h = wp(A, A.headG, 0, .66, 0, s); const ry = A.g.rotation.y + (o.ang ?? .35), d0 = o.d0 ?? 4.6, d1 = o.d1 ?? 4.0, dy = o.dy ?? .2, ly = o.ly ?? .5;
  cam(s, [h[0] + Math.sin(ry) * d0, h[1] + dy, h[2] + Math.cos(ry) * d0], [h[0] + Math.sin(ry) * d1, h[1] + dy * .8, h[2] + Math.cos(ry) * d1], [h[0], h[1] - ly, h[2]], [h[0], h[1] - ly, h[2]], u, o.fov ?? 44);
}
function put(o, s, x, y, z, ry = 0) { o.visible = true; o.position.set(s.position.x + x, y, s.position.z + z); o.rotation.set(0, ry, 0); return o; }
const FLAT = -Math.PI / 2;
all.forEach(a => a.g.rotation.order = 'YXZ');
function cw(s, A, u, o = {}) { const h = wp(A, A.headG, 0, .66, 0, s); const a = o.a ?? 0, d0 = o.d0 ?? 5, d1 = o.d1 ?? 4.4, dy = o.dy ?? .3, ly = o.ly ?? .45; cam(s, [h[0] + Math.sin(a) * d0, h[1] + dy, h[2] + Math.cos(a) * d0], [h[0] + Math.sin(a) * d1, h[1] + dy * .8, h[2] + Math.cos(a) * d1], [h[0], h[1] - ly, h[2]], [h[0], h[1] - ly, h[2]], u, o.fov ?? 44); }
const inPark = () => inSet('park', daySky), inRoom = () => inSet('room', '#b4d8e4');

let TIMING = null;
const capEl = document.getElementById('cap'), fadeEl = document.getElementById('fade'), titleEl = document.getElementById('title'), tagEl = document.getElementById('tag'), tintEl = document.getElementById('tint');
// PER EPISODE: caption keyword colours (y = names/things, r = danger/shock words, b = the rule/magic words)
const HL = { y: /^(alex|sam)$/i, r: /^(never|gone|dead|deadly|stop|no)$/i, b: /^(world|rule|wish|magic)$/i };
function chunks(words) {
  const out = []; let cur = [];
  words.forEach((w, i) => { cur.push(w); const end = /[.,!?…]["”]?$|\.\.\.$/.test(w.w); if (cur.length >= 3 || end || i === words.length - 1) { out.push(cur); cur = []; } });
  return out;
}
let CAP = { html: '', st: 0 };
function setCaption(t) {
  let html = '', st = 0;
  for (const seg of TIMING.segments) {
    if (t < seg.start - .05 || t > seg.chunkEnd) continue;
    const cs = seg.chunks;
    for (let i = 0; i < cs.length; i++) {
      const c = cs[i]; const s0 = c[0].s, s1 = i + 1 < cs.length ? cs[i + 1][0].s : seg.chunkEnd;
      if (t >= s0 - .02 && t < s1) {
        html = c.map(w => { const clean = w.w.replace(/["“”.,!?…]/g, ''); const cls = HL.r.test(clean) ? 'r' : HL.y.test(clean) ? 'y' : HL.b.test(clean) ? 'b' : ''; return `<span class="${cls}">${clean.toUpperCase()}</span>`; }).join(' ');
        st = t - s0;
      }
    }
  }
  capEl.innerHTML = html; CAP.st = st;
}
function speaking(seg, t) { if (!seg) return false; for (const w of seg.words) if (w.q && t >= w.s && t <= w.e) return Math.floor((t - w.s) * 9) % 2 === 0; return false; }
function wordT(seg, re, n = 0) { let c = 0; for (const w of seg.words) if (re.test(w.w)) { if (c++ === n) return w.s; } return seg.start; }
const lt = (seg, re, n) => wordT(seg, re, n) - seg.shotStart;
const flap = (t, on = true) => on && Math.floor(t * 9) % 2 === 0;
const fontTex = [];   // [texture, drawFn] pairs for canvas textures that use the Lucky font (redrawn once fonts load)

// ---------- TITLE + SHOTS (PER EPISODE) ----------
const TITLE = 'IN THIS WORLD,<br>EVERY <span class="r">RULE</span><br>IS <span class="r">DEADLY</span>';
// One function per segment id: (t = seconds into this shot, d = shot length, seg = segment, g = global time).
// lt(seg, /word/) = local time of a word (cut on words); speaking(seg, g) = mouth flap while quoted words play; flap(t) = free flap.
// Patterns: place(A, set, x, y, z, rotY); A.pose(P.walk(t)); A.setFace('shock', open); cam(set, from0, from1, look0, look1, u, fov);
//           closeUp(set, A, u, {ang, d0, d1}); ots(set, ax, az, bx, bz, u); tag('TEXT', x, y, opacity, 'r'); tint(color, o); flash(color, o); camShake = .08.
const shot = {
  h1(t, d, seg) {   // EXAMPLE hook: craziest image first + the title
    const s = inPark(); place(lead, s, 0, 0, 2, .2); lead.pose(P.shout(t)); lead.setFace('shock', speaking(seg, T));
    cam(s, [3, 5, 14], [2.4, 5.2, 12], [0, 4, 0], [0, 4.2, 0], t / d, 50);
    titleEl.style.opacity = 1; titleEl.innerHTML = TITLE;
  },
  b1(t, d, seg) {   // EXAMPLE build-up: two characters, cut on a word
    const s = inRoom(); const tC = lt(seg, /but/i);
    place(lead, s, -2, 0, 1, .4); place(side, s, 2, 0, 1, -.4);
    lead.pose(P.talk(t)); lead.setFace('smile', speaking(seg, T)); side.pose(P.idle(t)); side.setFace('neutral');
    if (t < tC) cam(s, [0, 5.5, 12], [0, 5.2, 10.5], [0, 3.8, 0], [0, 3.8, 0], t / tC, 48);
    else { closeUp(s, side, (t - tC) / (d - tC), { ang: -.3 }); side.setFace('worried'); }
  },
  ask(t, d, seg, g) {   // EXAMPLE comment question to camera, then loop back into the hook
    const tB = lt(seg, /Because/) - .05;
    if (t < tB) { const s = inPark(); place(lead, s, 0, 0, 2, 0); lead.pose(P.talk(t)); lead.setFace('smirk', speaking(seg, g)); closeUp(s, lead, t / tB, { ang: .1, d0: 6.4, d1: 5.6 }); tag('WOULD YOU?', 540, 330, clamp(t * 3), 'y'); }
    else { shot.h1(t - tB, d, TIMING.segments[0]); titleEl.style.opacity = 0; }
  },
};

function renderAt(g) {
  T = g;
  titleEl.style.opacity = 0; tagEl.style.opacity = 0; tintEl.style.opacity = 0; fadeEl.style.opacity = 0; fadeEl.style.background = '#000';
  const segs = TIMING.segments; let i = 0;
  for (let k = 0; k < segs.length; k++) if (g >= segs[k].shotStart) i = k;
  const seg = segs[i]; const t = g - seg.shotStart; const d = seg.shotEnd - seg.shotStart;
  (shot[seg.id] || (() => { }))(t, d, seg, g);
  fill.intensity = FILL; FILL = .7;
  setCaption(g);
  renderer.render(scene, camera);
}

window.setup = async (timing) => {
  TIMING = timing; const segs = TIMING.segments;
  segs.forEach((s, k) => { s.shotStart = k === 0 ? 0 : s.start - .08; s.chunks = chunks(s.words); });
  segs.forEach((s, k) => { s.shotEnd = k + 1 < segs.length ? segs[k + 1].shotStart : TIMING.total; s.chunkEnd = Math.min(s.end + .45, s.shotEnd); });
  await document.fonts.load('100px Lucky');
  fontTex.forEach(([t, draw]) => { draw(t.image.getContext('2d')); t.needsUpdate = true; });
  for (const s of segs) renderAt(s.shotStart + .5);
  return segs.map(s => [s.id, s.shotStart, s.shotEnd]);
};

// ---------- 2D compositor ----------
const outC = document.createElement('canvas'); outC.width = W; outC.height = H; const ox = outC.getContext('2d');
const COL = { y: '#ffe14a', r: '#ff3b3b', b: '#7fd8ff', w: '#ffffff', '': '#ffffff' };
function parseSpans(el) {
  const lines = [[]];
  el.childNodes.forEach(n => {
    if (n.nodeName === 'BR') { lines.push([]); return; }
    const cls = n.nodeType === 1 ? (n.className || '') : '';
    (n.textContent).split(/(\s+)/).forEach(p => { if (p.trim()) lines[lines.length - 1].push({ text: p, cls }); });
  });
  return lines.filter(l => l.length);
}
function drawText(lines, cx, cy, size, stroke, maxW, scale = 1, rot = 0) {
  ox.save(); ox.translate(cx, cy); ox.rotate(rot); ox.scale(scale, scale);
  ox.font = `${size}px Lucky`; ox.textBaseline = 'middle'; ox.lineJoin = 'round';
  const out = []; for (const l of lines) { let cur = [], w = 0; for (const wd of l) { const ww = ox.measureText(wd.text + ' ').width; if (cur.length && w + ww > maxW) { out.push(cur); cur = []; w = 0; } cur.push(wd); w += ww; } if (cur.length) out.push(cur); }
  const lh = size * 1.08; let y = -((out.length - 1) * lh) / 2;
  for (const l of out) {
    const sp = ox.measureText(' ').width; const tw = l.reduce((a, wd) => a + ox.measureText(wd.text).width, 0) + sp * (l.length - 1);
    let x = -tw / 2;
    for (const wd of l) {
      const w = ox.measureText(wd.text).width;
      ox.fillStyle = 'rgba(0,0,0,.85)'; ox.lineWidth = stroke; ox.strokeStyle = 'rgba(0,0,0,.85)'; ox.strokeText(wd.text, x, y + size * .09); ox.fillText(wd.text, x, y + size * .09);
      ox.strokeStyle = wd.cls === 'w' ? '#3a6fd0' : '#000'; ox.strokeText(wd.text, x, y); ox.fillStyle = COL[wd.cls] || '#fff'; ox.fillText(wd.text, x, y);
      x += w + sp;
    }
    y += lh;
  }
  ox.restore();
}
function compose() {
  ox.drawImage(renderer.domElement, 0, 0, W, H);
  const to = +tintEl.style.opacity || 0; if (to > 0) { ox.globalAlpha = to; ox.fillStyle = tintEl.style.background || '#000'; ox.fillRect(0, 0, W, H); ox.globalAlpha = 1; }
  const vg = ox.createRadialGradient(W / 2, H / 2, H * .3, W / 2, H / 2, H * .62); vg.addColorStop(0, 'rgba(0,0,0,0)'); vg.addColorStop(1, 'rgba(0,0,0,.45)'); ox.fillStyle = vg; ox.fillRect(0, 0, W, H);
  if (+titleEl.style.opacity > 0) drawText(parseSpans(titleEl), W / 2, 380, 108, 16, 1000);
  if (+tagEl.style.opacity > 0) { ox.globalAlpha = +tagEl.style.opacity; const big = /^\d$/.test(tagEl.textContent); drawText([tagEl.textContent.split(' ').map(w => ({ text: w, cls: tagEl.dataset.cls || 'y' }))], parseFloat(tagEl.style.left), parseFloat(tagEl.style.top), big ? 300 : 96, big ? 30 : 15, 1000); ox.globalAlpha = 1; }
  if (capEl.innerHTML) { const st = CAP.st; const k = st < .12 ? lerp(.6, 1.12, st / .12) : st < .22 ? lerp(1.12, 1, (st - .12) / .1) : 1; drawText(parseSpans(capEl), W / 2, 1320, 118, 18, 1000, k, Math.sin(st * 3) * 1.2 * Math.PI / 180); }
  const fo = +fadeEl.style.opacity || 0; if (fo > 0) { ox.globalAlpha = fo; ox.fillStyle = fadeEl.style.background || '#000'; ox.fillRect(0, 0, W, H); ox.globalAlpha = 1; }
}
window.frameJPEG = (g) => { renderAt(g); compose(); return outC.toDataURL('image/jpeg', .92); };
window.renderAt = renderAt;
window.ready = true;
window.ENG = { THREE, scene, camera, renderer, avatar, P, sets, showOnly, hideAll, all, fill, faceTex, canvasTex };