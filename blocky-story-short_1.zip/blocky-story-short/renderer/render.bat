@echo off
title Blocky Story render
cd /d "%~dp0"
node render.js %*
pause
