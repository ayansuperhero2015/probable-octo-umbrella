// Runs quietly in the background (started at Windows login by setup.bat).
// When Claude drops episodes/<ep>/go.json, it renders that episode automatically:
//   go.json      -> request (optional {"title": "...", "copyTo": "../<Title>"})
//   running.json -> render in progress (see progress.txt)
//   done.json    -> finished; final.mp4 is ready (and copied to copyTo/<title>.mp4 if given)
//   error.txt    -> failed; the reason is inside
const fs = require('fs');
const path = require('path');
const { render } = require('./render');

const ROOT = __dirname;
const EPS = path.join(ROOT, 'episodes');
const LOCK = path.join(ROOT, 'watcher.lock');
const log = (s) => console.log(new Date().toISOString() + ' ' + s);

// one watcher at a time
try {
  const pid = Number(fs.readFileSync(LOCK, 'utf8'));
  if (pid && pid !== process.pid) { process.kill(pid, 0); log('watcher already running (pid ' + pid + ')'); process.exit(0); }
} catch (e) { /* no lock or stale lock */ }
fs.writeFileSync(LOCK, String(process.pid));
const cleanup = () => { try { if (Number(fs.readFileSync(LOCK, 'utf8')) === process.pid) fs.unlinkSync(LOCK); } catch (e) {} };
process.on('exit', cleanup);
process.on('SIGINT', () => process.exit(0));
fs.writeFileSync(path.join(ROOT, 'watcher.heartbeat'), new Date().toISOString());

const safe = (s) => String(s).replace(/[<>:"/\\|?*\x00-\x1f]/g, '').replace(/[. ]+$/, '').trim().slice(0, 120) || 'episode';
let busy = false;

async function tick() {
  try { fs.writeFileSync(path.join(ROOT, 'watcher.heartbeat'), new Date().toISOString()); } catch (e) {}
  if (busy || !fs.existsSync(EPS)) return;
  for (const ep of fs.readdirSync(EPS)) {
    const dir = path.join(EPS, ep);
    const go = path.join(dir, 'go.json');
    if (!fs.existsSync(go)) continue;
    busy = true;
    let req = {};
    try { req = JSON.parse(fs.readFileSync(go, 'utf8') || '{}'); } catch (e) {}
    for (const f of ['done.json', 'error.txt', 'final.mp4']) { try { fs.unlinkSync(path.join(dir, f)); } catch (e) {} }
    fs.renameSync(go, path.join(dir, 'running.json'));
    log('rendering ' + ep);
    try {
      const out = await render(ep, {});
      const result = { finished: new Date().toISOString(), file: out };
      if (req.title) {
        const title = safe(req.title);
        const dest = path.resolve(ROOT, req.copyTo || path.join('..', title));
        fs.mkdirSync(dest, { recursive: true });
        const target = path.join(dest, title + '.mp4');
        fs.copyFileSync(out, target);
        result.copiedTo = target;
      }
      fs.writeFileSync(path.join(dir, 'done.json'), JSON.stringify(result, null, 2));
      log('done ' + ep);
    } catch (e) {
      fs.writeFileSync(path.join(dir, 'error.txt'), e.stack || String(e));
      log('FAILED ' + ep + ': ' + e.message);
    }
    try { fs.unlinkSync(path.join(dir, 'running.json')); } catch (e) {}
    busy = false;
    return;
  }
}

log('watcher started, watching ' + EPS);
setInterval(tick, 5000);
tick();
