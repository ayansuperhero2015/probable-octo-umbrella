@echo off
cd /d "%~dp0"
del "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\blocky-story-render-watcher.vbs" 2>nul
if exist watcher.lock (
  for /f %%p in (watcher.lock) do taskkill /pid %%p /f >nul 2>nul
  del watcher.lock 2>nul
)
echo Auto-render turned off. Run setup.bat to turn it back on.
pause
