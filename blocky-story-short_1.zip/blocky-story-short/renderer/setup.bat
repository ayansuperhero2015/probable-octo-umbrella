@echo off
title Blocky Story renderer setup
cd /d "%~dp0"
echo.
echo  Blocky Story renderer setup
echo  ---------------------------
where node >nul 2>nul
if errorlevel 1 (
  echo  Node.js is not installed yet. Opening the download page...
  echo  Install the "LTS" version, then double-click setup.bat again.
  start "" https://nodejs.org/en/download
  pause
  exit /b 1
)
echo  Installing renderer parts (one time, about a minute)...
call npm install --no-audit --no-fund
if errorlevel 1 (
  echo  Install failed. Copy the text above and paste it to Claude.
  pause
  exit /b 1
)
node install_startup.js
echo.
echo  All set! Videos will now render on this PC automatically.
echo  You can close this window.
pause
