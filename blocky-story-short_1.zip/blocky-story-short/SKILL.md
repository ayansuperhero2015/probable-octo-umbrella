---
name: "blocky-story-short"
description: "Make a Roblox-style blocky-avatar story YouTube Short with a big plot twist, rendered automatically on your own PC's graphics card with free AI narration. First run sets up your channel (voice, characters, looks, format) and the PC renderer; later runs reuse it."
---

# Blocky Story Short

Makes vertical YouTube Shorts in the "blocky avatar story" genre: a narrator tells a short, punchy story with a massive mid-video plot twist, acted out by original blocky 3D characters, with word-timed pop-in captions. Everything is made from scratch for THIS user's own channel: their voice, their characters, their look, their opener line. Never copy another creator's channel name, characters, catchphrases or stories.

Hard rules (every episode):
- Original blocky avatars only: no Roblox logo, wordmark, fonts or official assets, and no known characters.
- Vertical 1080x1920, 30fps.
- Narration is free: Chatterbox (open source) or edge-tts. Don't use paid voice services unless the user asks and has their own account.
- Never upload or publish anything unless the user asks in this conversation.

## 0. First run: set up the channel (only if no profile exists)

Look for a saved profile first: a `channel_profile.md` in a folder the user has connected (or one they attach), or the user's memory. If found, read it, say in one line which channel you're making an episode for, and skip to step 0b.

If there's no profile, this is the user's first time. Greet them in one or two sentences ("Let's set up your channel so these videos feel like yours, not a copy of anyone else's.") and ask with AskUserQuestion, in two rounds of up to 4 questions (always let them type their own answer):

Round 1: the channel
1. Channel name (or "help me pick one": offer 3).
2. Opening line style. Every episode opens with the same signature hook, so it's recognizable. Offer: "In this world, ..." / "Imagine a world where ..." / "What if ..." / "Everyone in this town ..." / their own.
3. Narrator voice: what should it sound like? Options: deep and dramatic / young and energetic / calm and creepy / funny and fast. Then the source: (a) a free built-in voice (Chatterbox default, or pick an edge-tts voice; play 2-3 short samples so they can choose), or (b) clone from a 10-20s clean clip they upload of THEIR OWN voice (or one they have permission to use; never clone a celebrity or real person without consent). Also ask: normal pitch, slightly higher, or slightly lower.
4. Video length: ~1 min / ~1:30 / ~2:00-2:30 (default 2:00-2:30; longer Shorts with a strong mid twist tend to hold viewers well; Shorts can be up to 3 min).

Round 2: the cast and look
1. Main character: name, shirt color, hair (messy / swoop / long / bun / cap / bald), skin tone, any extra (glasses, beard, hat, hoodie). Offer 3 quick ready-made looks + "describe your own".
2. Sidekick or recurring second character? (same detail, or "no sidekick", or "new characters each episode").
3. Overall visual vibe: bright and colorful / dark and dramatic / cozy pastel / neon night. Caption style: big bold yellow-and-white / clean white / colorful per keyword.
4. Music: none / soft background music from the YouTube Audio Library (copyright-safe only) / decide per episode.

Then write `channel_profile.md` with every answer (channel name, opener, voice choice + settings + reference clip filename, length target, cast with exact looks, vibe, caption style, music, and an empty "Episode log" + "Things the user asked to change" section). Save it into the user's connected folder (ask them to connect or pick a folder for the channel; create `<Channel name>/` inside it), and show them a 3-line summary. If no folder can be connected, SendUserFile it and tell them to keep it and attach it next time.

### Set up the PC renderer (first run only)

Full videos render automatically on the user's own PC with its graphics card (a 2-minute Short takes ~5 min instead of ~35 in the cloud). This skill ships the renderer in its `renderer/` folder (render.js, watcher.js, index.html, setup.bat, render.bat, test_render.bat, uninstall.bat, install_startup.js, package.json). Find it next to this SKILL.md (e.g. `find / -path "*blocky-story-short/renderer/render.js" 2>/dev/null`).

1. Check the PC is reachable (any remote-devices call). If the session isn't linked to their computer, tell them to start the task from the Claude desktop app on their PC, and use the cloud fallback (step 6) meanwhile.
2. Copy the renderer files into `<Channel name>/renderer/` in their connected folder (device_commit_files via /mnt/user-data/outputs, or device_bash). Keep the .bat files' CRLF line endings. Don't copy node_modules.
3. Ask them to double-click `setup.bat` in that folder, ONCE. It checks for Node.js (opens the download page if missing: install the LTS version, then run setup.bat again), installs the parts, and turns on auto-render: a small hidden helper (watcher.js) starts at every Windows login and renders any episode Claude hands it. It uses almost nothing while idle and renders at below-normal priority. `uninstall.bat` turns it off.
4. Confirm it worked: `renderer/watcher.heartbeat` exists and its timestamp keeps updating (written every 5s). If not, ask them to paste what the setup window says.
5. The test still below can already go through the PC: it proves the graphics card is being used (the progress line names the GPU; "no graphics card found" means software rendering).

This is the only thing they ever click. From then on, every render starts by itself.

Before building anything, render a test (base engine + CAST from the profile, a simple set in their vibe): one still image of the main cast standing together in the chosen vibe, plus a 5-second voice sample of the narrator saying the opener. Ask "Look and sound right?" and adjust until yes. Save the approved character settings into the profile.

## 0b. Every episode: the story

Ask with AskUserQuestion (one round):
- The story. First episode: ask "What's your first story idea?" and offer 3 fresh premises in the channel's opener style (e.g. "In this world, every lie leaves a mark on your skin"), each with a one-line hint of the twist, + "I'll write my own". Later episodes: same, but never repeat a premise from the episode log.
- Which characters star (recurring cast / add a new one).
- Anything different this time (music, length), defaulting to the profile.

If the user writes their own premise and the ending isn't clear, ask how it should go.

## 1. Script: 5-part structure + comment question

Word target from length: ~2.5 words/second of final runtime including gaps (1:00 ≈ 150 words, 2:00-2:30 ≈ 300-375). Count words before showing the script. Short punchy sentences; dialogue in double quotes.

| Segment | Goal | Share of runtime |
|---|---|---|
| **Hook** | Open with the channel's signature opener and the craziest part FIRST (the rule, the shocking image). No slow setup. | first ~3-6s |
| **Build-up** | Who the lead is, how the rule works, what's at stake. 3-4 escalating beats for longer videos. Plant a subtle clue for the twist. | to ~35-40% |
| **Micro-hook** | A MASSIVE twist right where viewers get bored. It flips what we thought and raises a burning question. | ~40-50% |
| **Climax** | Answer that question, with one more obstacle or turn, up to the biggest reveal. | to ~92% |
| **Comment question + loop** | The lead turns to the camera and asks the viewer ONE short, fun, specific question (a choice or "what would you do?", under ~12 words, not an obvious yes/no), then a few words that lead back into the opener so the Short replays seamlessly. Never "thanks for watching", never ask for likes/subs. | last ~4-6s |

- Write `segments.json`: array of `{id, text, part}` (part = hook/buildup/microhook/climax/loop), one entry per shot (2-6s each; ~30-38 shots for 2 min). Words inside quotes animate the speaker's mouth.
- Micro-hook emphasis: hard cut + boom SFX + red tint.
- SHOW THE FULL SCRIPT (with word count and estimated runtime) AND GET A YES before voicing or rendering. Expect redirects; keep each version tight and ask again after every change.

## 2. Setup (cloud workspace)

Start in the background right after 0b so it's ready when the script is approved:
```
mkdir -p ~/ep && cp -r <skill>/renderer ~/ep/renderer && cd ~/ep/renderer && npm i --no-audit --no-fund
pip install faster-whisper --break-system-packages
pip install chatterbox-tts --break-system-packages --extra-index-url https://download.pytorch.org/whl/cpu   # ~2 min
```
Playwright + Chromium are preinstalled (`require('playwright')`). render.js serves its own files, so no web server is needed. Start background jobs with `(setsid nohup cmd > log 2>&1 < /dev/null &)`. Never `pkill -f chrom` (kills your own shell).

## 3. Narration

- Chatterbox: one generation per segment -> `seg_<id>.wav`, `cfg_weight=.4`, per-line `exaggeration` (.5 calm, .6-.7 normal, .85-.9 shouts, shocks, micro-hook and twist; ~.7 for the comment question). With a reference clip: `ffmpeg -ss 1 -t 14 -i clip -ac 1 -ar 24000 ref.wav` and pass `audio_prompt_path`. Without one, use Chatterbox's default voice. ~20-30s per line on CPU; run in the background and check `grep -c ^done gen.log` (don't tail the log).
- edge-tts (if the user picked it, or Chatterbox won't install): chosen voice + rate, patch its SSL context with `/root/.ccr/ca-bundle.crt` if TLS fails. Mention it has less emotion.
- Text gotchas: strip double quotes; write ALL-CAPS words in lowercase; numbers as words.
- Check every line: transcribe with faster-whisper, compare to the script (difflib ratio), regenerate bad lines.
- Stitch: trim silence (keep 30ms head / 80ms tail), join with 0.28s gaps (0.5s before the micro-hook, the twist and the question) -> `voice_raw.wav`.
- Pitch from the profile: `asetrate=24000*<1.0 normal / 1.08-1.12 higher / 0.92 lower>,aresample=48000,loudnorm=I=-14:TP=-1.5:LRA=11` -> `voice.wav`.

## 4. Timing

Get word timestamps with faster-whisper small.en (feed a 16kHz float32 numpy array; don't use an initial_prompt, it makes whisper hallucinate), then difflib-align the script words to them -> `timing.json` (per segment: start, end, words with times). LENGTH CHECK against the profile target: if short, add a story beat (show the user the new lines) and voice only those; if long, cut a line. Never pad silence or slow the voice.

## 5. Engine: start from the shipped base engine

Work in a cloud copy of the shipped renderer: `cp -r <skill>/renderer ~/ep/renderer && cd ~/ep/renderer && npm i`. Each episode lives in `episodes/<ep>/` (short id like `lie_scar`) with `engine.js`, `timing.json` and `mix.wav`.

`renderer/engine/base_engine.js` is a tested, working engine. Never rebuild it from scratch. First episode: copy it to `episodes/<ep>/engine.js`. Later episodes: start from the channel's latest `engine/engine.js` saved in their folder (it has their cast and every set built so far) and copy in any sets you need from older episodes.

What the library gives you (read the top of the file):
- `avatar(o)`: rounded blocky body with pivoting arms/legs/head. Options: skin, shirt, sleeve, pants, shoes, hair, hairStyle (messy / swoop / long / bun / cap), face, scale (kids ~.62-.72), watch. Add new hair styles or extras (glasses, hats, hoodies) inside `avatar()` when the profile asks for them. `A.setFace(expr, mouthOpen)` with faces smile, neutral, shout, happyclosed, closed, squeeze, scared, shock, worried, sad, angry, smirk, grin, sus, cold, cry, blank. `A.brush` is an empty hand-held prop slot.
- Poses `P.*(t)`: idle, walk, run, talk, shout, cheer, wave, laugh, hairTouch, lean, cross, brush, catch, press, pound, reach, throw, duck, fall, hop, grab, around, check, armlook, back, hug. Combine: `A.pose({ ...P.idle(t), hy: .3 })`.
- Sets: `mkSet(name, x, z)` (each set far from the others), `ground`, `sky`, `sun` (shadows), `box`, `plane`, `signTex`, `canvasTex`, `studTex`, `tileTex`. `inSet(name, background)` shows one set and resets everyone.
- Camera: `cam(set, from0, from1, look0, look1, u, fov)` eased moves, `closeUp(set, A, u, {ang, d0, d1})`, `ots(...)` over-the-shoulder, `cw(...)`, `camShake`.
- Overlays: hook title (`titleEl` + TITLE), `tag(text, x, y, opacity, 'y'|'r'|'b')`, `tint(color, o)`, `flash(color, o)`, word-timed pop-in captions coloured by the `HL` regexes, `burst(...)` particle pops. A 2D compositor bakes everything into each frame (`window.frameJPEG`).
- Timing helpers: `lt(seg, /word/)` (local time of a word: cut on words), `speaking(seg, g)` (mouth flaps only while that segment's quoted words play), `flap(t)`.

Per episode, edit ONLY the sections marked `PER EPISODE`: CAST (from the profile's exact looks), SETS (locations in the channel's vibe; the two example sets and example shots are placeholders, replace them), `resetAll()`, `HL` keywords, `TITLE`, and the `shot{}` object (one function per segment id: `(t, d, seg, g)`).
- `timing.json` format: `{ total, segments: [ { id, part, text, start, end, words: [ { w, s, e, q } ] } ] }` (q = word is inside quotes).
- `lt()` falls back to the segment start when a word isn't found, so a branch on a missing word fires immediately: after timing, verify every cue regex hits a word in its segment.
- Vary framing (wide / medium / close-up / over-shoulder); no framing longer than ~4s; split long segments on words. Face close-ups: fov ~42-46, face in the upper half so captions don't cover it.
- The question shot (`ask`): lead turns to camera, medium close-up, `P.talk`, slight push-in, question as a big `tag()` up top; on the lead-back words call `shot.h1(...)` so the replay is seamless (see the example).
- `render.js` (shipped): `node render.js <ep> --stills 3,8,22` -> `episodes/<ep>/stills/*.jpg`; `--seconds 3` a test clip; no flag = the full video -> `episodes/<ep>/final.mp4` with mix.wav. Edge/Chrome with the GPU on Windows (falls back to a hidden off-screen window if headless gets no GPU), preinstalled Playwright Chromium in the cloud.
- Gotchas: right arm out/up = positive aRz, left = negative; keep cameras outside solid boxes (blank frames); fov 36-38 crops heads; carried props held low (y ~2.4) so they don't hide faces; a lying avatar's feet are the root; doors need a real wall gap; keep interiors and night scenes bright.

## 6. Preview, then full render

- While the voice generates, fake a timing.json (0.36s/word, 0.4s between segments) and render 2 stills per shot (start+.5s and end-.3s), tile them into contact sheets and LOOK at every shot (always the hook, micro-hook, question close-up and last frame). Fix framing and lighting, then re-check key stills with real timing.
- Stills render in the cloud (quick). The full render happens on the PC, automatically (step 7b), after the sound mix is done.
- Cloud fallback ONLY if the PC isn't reachable, the watcher isn't running and they can't run setup.bat now, or they say they're away: `(setsid nohup node render.js <ep> > render.log 2>&1 < /dev/null &)` (~0.2-0.5s/frame, a 2-min episode ≈ 15-40 min), check `progress.txt` every ≤9 min, and tell them roughly how long.

## 7. Sound

- SFX script (numpy synth): booms on the micro-hook and twist, location ambience, whooshes on cuts, rings/ticks/heartbeat etc. as the story needs; keep the question line clean.
- Mix: `[1]volume=0.5` sfx under voice, `amix ... normalize=0, alimiter=0.95` -> `mix.wav`, ~-15 LUFS.
- Music only if the profile/episode says so: copyright-safe YouTube Audio Library tracks the user downloads themselves, ducked under the voice with sidechaincompress; credit it in the description if the license asks.

### 7b. Automatic render on the PC (default)

1. Pick the title first, in the channel's opener style (no `: ? * / \ " < > |`).
2. Commit `engine.js`, `timing.json` and `mix.wav` to `<Channel name>/renderer/episodes/<ep>/` (force:true when replacing). If you changed index.html or render.js, commit those too.
3. Commit LAST a `go.json` into the same folder: `{"title": "<Title>"}`. The watcher sees it within 5s, renames it to `running.json`, renders, and copies the video to `<Channel name>/<Title>/<Title>.mp4`, then writes `done.json` (or `error.txt` if it failed). Re-dropping go.json re-renders (old final.mp4 is replaced).
4. Check it started: within ~15s `running.json` and `progress.txt` appear (progress shows frame count, fps, time left and the GPU name). If go.json is still sitting there after ~30s, the watcher isn't running (PC was restarted before setup, or uninstalled): ask them to double-click `setup.bat` again (it restarts the watcher); if they can't right now, use the cloud fallback.
5. Tell the user it's rendering on their PC and about how long (from progress.txt). Poll `progress.txt` / `done.json` every ~2 min (device_bash `cat`, or device_stage_files the small text file).
6. On `error.txt`: read it, fix the cause (usually an engine error), re-commit, drop go.json again.

## 8. Verify and deliver

- Check the final (device_stage_files `<Channel name>/<Title>/<Title>.mp4`, or the cloud file): duration within target, 1080x1920, sample 8-10 frames at key word times (captions match the voice).
- The video is already in `<Channel name>/<Title>/`; commit `script.txt` next to it. Cloud fallback only: make a 2-pass H.264 copy under the device commit limit (~30MB) and commit it there; no folder connected -> SendUserFile it.
- Save the episode's `engine.js`, the sfx script and `segments.json` into `<Channel name>/engine/` so the next episode starts from them, and add a line to the profile's Episode log (title, premise, twist). The profile also records that the PC renderer is set up.
- Give ready-to-paste upload text: title, description (hook line + "wait for the twist" + music credit if any), hashtags (`#shorts #robloxstory #plottwist #storytime` + 3-4 fitting the story), and a pinned comment repeating the lead's question.
- Note: "Made for kids" turns comments off, which defeats the comment question; that choice is the user's.

## 9. Always end with this

Close every delivery with, in your own words:

"Here's your episode! If anything isn't good enough, just tell me what to fix: a line that sounds off, a shot that looks weird, a character's look, the pacing, the ending, anything. I'll fix just that part without redoing the whole video."

Then when they ask for a fix: change only what they named, re-render only what's needed (one voice line, a few shots, or the full render if timing changed), and add the preference to the profile's "Things the user asked to change" section if it should apply to future episodes too (e.g. "voice a bit slower", "main character always wears a cap"), so it's never repeated.
