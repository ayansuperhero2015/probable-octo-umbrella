---
name: chatterbox-voice
description: "Free AI voiceovers with Chatterbox (open-source TTS by Resemble AI): clone a voice from a clip, design new voices, keep a voice library, and generate checked, emotional narration with tested scripts. Use for any voiceover, narration, voice clone or 'make a voice' request."
---

# Chatterbox Voice

Free, open-source text-to-speech that runs in Claude's own workspace (no credits, no API key). It clones a voice from a short clip and has a real emotion control, so narration doesn't sound flat. Everything here is tested; use the scripts in `scripts/` instead of writing new ones.

Find this skill's folder first: `S=$(dirname $(find / -path "*chatterbox-voice/scripts/tts.py" -not -path "/proc/*" 2>/dev/null | head -1))`.

## Rules

- Only clone a voice the user owns or has permission to use (their own voice, a voice actor who agreed, a voice they made with design_voice.py). Don't clone celebrities, public figures or private people without consent, and don't make audio meant to pass as a real person saying something they didn't say. If asked, say so in one line and offer to design an original voice instead.
- Chatterbox adds an inaudible Perth watermark to everything it generates (marks it as AI audio). Don't try to remove it.
- Show the user a short test (one or two lines) before generating a long script in a new voice.
- Don't use paid voice services (ElevenLabs etc.) unless the user asks and has their own account.

## 1. Setup (once per session, ~2 min)

```
pip install chatterbox-tts faster-whisper edge-tts --break-system-packages --extra-index-url https://download.pytorch.org/whl/cpu
```
The CPU build of torch is the right choice in the cloud workspace (no GPU there). The first run downloads the model (~3 GB, ~30s) from Hugging Face. Start the install in the background as soon as the user asks for a voice, and work on the script while it runs.

## 2. The voice library

Voices live in the user's folder as `Voices/<voice-name>/` with `ref.wav` (the reference clip) and `voice.json` (its settings), so every voice is reusable in later sessions. If the user has a folder connected, keep the library there (ask which folder the first time, and stage/commit the voice folders as needed). Otherwise keep it in the workspace and send them a zip of `Voices/` at the end so they can attach it next time.

voice.json:
```json
{ "name": "Gruff Narrator", "ref": "ref.wav", "model": "original", "exaggeration": 0.5, "cfg": 0.5,
  "temperature": 0.8, "pitch": 1.0, "pitch_mode": "chipmunk", "speed": 1.0, "seed": null, "source": "...", "notes": "" }
```
When the user tunes a voice ("a bit deeper", "less dramatic"), save the change into its voice.json and write what they liked in `notes`.

## 3. Get a voice

Ask (AskUserQuestion) which way, unless it's obvious:

**a) Clone a recording.** The user uploads a clip, or it's in their folder.
`python3 -I $S/design_voice.py from-file --name "My Voice" --file clip.m4a --dir Voices`
- `make_ref.py` (called for you) converts to 24 kHz mono, cleans rumble/hiss, and auto-picks the best ~9 s of continuous speech. Use `--start SEC` to choose the spot yourself.
- Chatterbox only listens to the FIRST 10 s of a reference (and the first 6 s for speaking style), so longer clips add nothing. What matters: one speaker, no music or background noise, no reverb, natural expressive speech in the style wanted (a calm clip gives a calm voice).
- Any format ffmpeg reads works: mp3, wav, m4a, mp4/mov (audio is extracted), webm, ogg.

**b) Design a new voice (no recording).** Chatterbox can't make a voice from a description, so make a reference first, then Chatterbox adds the emotion:
- From a free Microsoft neural voice: `python3 -I $S/design_voice.py list-edge --filter en-US` to see options (gender + personality tags), then
  `python3 -I $S/design_voice.py from-edge --name "Gruff Narrator" --edge en-US-ChristopherNeural --rate=-5% --pitch=-4Hz --dir Voices`
  (write negative values with `=`). Offer 3 matching candidates for the description and let the user pick by ear.
- Reshape an existing voice into a different-sounding person: `python3 -I $S/design_voice.py from-ref --name "Tiny Hero" --ref Voices/gruff-narrator/ref.wav --shift 1.2 --dir Voices`. `--shift` moves pitch and formants together: 0.8-0.9 = bigger/deeper person, 1.15-1.3 = smaller/younger. Stay within 0.75-1.35 or it gets robotic.
- Other locales: `--filter en-GB`, `en-AU`, `es-`, etc.

**c) Built-in default voice.** Leave out `--voice/--ref` (original model only). Fine for quick tests.

Then always make a test line and send it: `python3 -I $S/tts.py --voice Voices/<v>/voice.json --text "..." --out Voices/<v>/test` -> convert to mp3 (`ffmpeg -i in.wav -b:a 160k out.mp3`) and SendUserFile it. Ask "sound right?" and tune (step 6) until yes.

## 4. Write the lines file

Split the script into lines of one or two sentences each (Chatterbox gets unstable past ~25-30 words or ~20 s per generation; longer text must be split). `lines.json`:
```json
[ {"id": "01", "text": "In this town, nobody is allowed to whisper.", "exaggeration": 0.5},
  {"id": "02", "text": "\"Wait. Did you hear that?\" she asked.", "exaggeration": 0.7},
  {"id": "03", "text": "He had $1,500 and ONE chance to RUN!", "exaggeration": 0.9, "gap_before": 0.5} ]
```
Ids sort in order (use 01, 02, ... or names). Per-line keys override voice.json: `exaggeration`, `cfg`, `temperature`, `gap_before` (stitch), `lang` (multilingual).

Text is cleaned automatically (`textclean.py`): quotes removed, numbers/money/percent/times written as words, ALL-CAPS words lowercased (Chatterbox spells them out letter by letter: "ONE" -> "O-N-E"), "..." -> comma pause. Use `--no-clean` to send text exactly as written. For emphasis, use punctuation and exaggeration, not caps. Write tricky names the way they sound ("Niamh" -> "Neeve").

## 5. Generate, check, stitch, finish

```
cd <work dir>
(setsid nohup python3 -I $S/tts.py --lines lines.json --voice Voices/<v>/voice.json --out segs > gen.log 2>&1 < /dev/null &)
grep -c ^done gen.log                       # progress (don't tail gen.log: progress bars flood it)
python3 -I $S/check.py --lines lines.json --dir segs --delete-bad
# if any were bad: re-run the same tts.py command (existing lines are skipped), then check again
python3 -I $S/stitch.py --lines lines.json --dir segs --out voice_raw.wav [--gap 0.28]
python3 -I $S/finish.py voice_raw.wav voice.wav --voice Voices/<v>/voice.json [--lufs -14]
```
- Speed on the 2-CPU cloud workspace: model load ~15-40 s, then ~6-8x real time (a 3 s line takes ~20-25 s; a 2-minute script ~15-20 min). Run it in the background and tell the user roughly how long. Do other work meanwhile.
- `check.py` transcribes each line with faster-whisper and compares it to the script (also flags lines that are too fast/slow: skipped words, stretched mumbling). Chatterbox sometimes swaps tenses, drops a word or adds a breathy tail; regenerating usually fixes it. If a line fails 3 times, rephrase it slightly or lower exaggeration/raise cfg.
- `stitch.py` trims silence and end-of-line tails, joins with gaps (longer `gap_before` before big moments), and writes `voice_raw_times.json` (start/end of every line, useful for captions or video timing).
- `finish.py`: `--pitch 1.1` = 10% higher. Default `chipmunk` mode also speeds up slightly (sped-up-tape sound, punchy for Shorts); `--mode keep` changes pitch only. `--speed 1.1` = faster without pitch change. Loudness: -14 LUFS for YouTube/TikTok, -16 podcasts, -19 audiobooks. Output is 48 kHz WAV; convert to mp3/m4a for delivery if wanted.
- Single quick line: `tts.py --text "..." --out dir` then finish.py on it.

Deliver: send the final file (mp3 for listening, wav for editing) and save it beside the user's project if a folder is connected. Tell them you can't hear the tone yourself, and offer to redo any single line ("line 07 sounds too calm").

## 6. Tuning guide (what to change when the user says...)

| User says | Change |
|---|---|
| flat / boring / robotic | raise `exaggeration` (0.6-0.8); keep cfg ~0.3-0.4 |
| over the top / shouty / unstable | lower exaggeration (0.35-0.5), raise cfg (0.5-0.6) |
| too fast | lower `cfg` to ~0.3 (slower, more deliberate) or `finish.py --speed 0.95`. High exaggeration speeds speech up, so pair it with lower cfg |
| too slow / draggy | raise cfg to 0.6, or `--speed 1.05-1.1` |
| doesn't sound like the reference / accent drifts | cleaner or more typical reference clip; raise cfg; for a non-English reference speaking English, set cfg 0 to stop accent transfer |
| different every line / inconsistent | set `"seed": 42` in voice.json and lower temperature to 0.6-0.7 |
| deeper / higher | `pitch` in voice.json (0.92 deeper, 1.08-1.12 higher), or make a new reshaped voice with `--shift` |
| one line has the wrong delivery | regenerate just that line (delete its wav) with a different exaggeration, or use voice conversion (step 7) |

Emotion presets for per-line exaggeration: calm narration 0.4-0.5, normal 0.6-0.7, excited/scared/shouting/twist 0.85-1.0.

## 7. Other models and tools

- `--model turbo` (Chatterbox Turbo): ~2-3x faster on CPU; needs a reference voice longer than 5 s; ignores exaggeration/cfg. Sound tags inline in the text: `[laugh]` `[chuckle]` `[sigh]` `[gasp]` `[cough]` `[sniff]` `[groan]` `[clear throat]` `[shush]`. Its vocabulary also has style tags (`[whispering]` `[angry]` `[happy]` `[fear]` `[surprised]` `[sarcastic]` `[crying]` `[dramatic]` `[narration]`); results vary, so test them on a line first. Tags pass through the text cleaner unchanged. Use turbo when speed or laughs/sighs matter more than the emotion slider.
- `--model multilingual --lang es` (23 languages: ar da de el en es fi fr he hi it ja ko ms nl no pl pt ru sv sw tr zh). Use a reference in the target language for the best accent, or cfg 0 to avoid accent bleed.
- Voice conversion: `python3 -I $S/convert.py performance.m4a out.wav --voice Voices/<v>/voice.json` keeps the timing and acting of any recording (e.g. the user acting out a line on their phone) but in the saved voice. Great for lines TTS can't deliver right.
- edge-tts alone (no Chatterbox) is a fast fallback if Chatterbox can't install: lower emotion, but instant. Tell the user it sounds flatter.

## Gotchas

- Run scripts with `python3 -I` (isolated mode); the scripts add their own folder to the import path.
- `edge-tts` behind the workspace proxy: design_voice.py points its SSL context at `/root/.ccr/ca-bundle.crt` automatically.
- Start long jobs with the `(setsid nohup ... &)` form above so they survive between turns. Check with `grep -c ^done gen.log` and `grep -i error gen.log`.
- check.py and the "done" log show `ex=`/`cfg=` even for turbo; turbo ignores them.
- If transcripts from faster-whisper look hallucinated, never pass an `initial_prompt`.
- A wav that's much longer than its text (e.g. 15 s for 8 words) is a runaway generation: check.py flags it; regenerate.
