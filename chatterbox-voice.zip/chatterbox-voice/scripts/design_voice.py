#!/usr/bin/env python3
"""Make a NEW voice (no recording needed) and save it as a reusable voice folder.

Chatterbox can't invent a voice from a text description, it copies a reference clip. So this script
makes a reference clip first, then saves it with settings. Chatterbox then speaks with that voice
and adds real emotion on top.

Ways to make the reference:
  from-edge   : a free Microsoft neural voice (edge-tts) reads a sample paragraph; you pick voice, rate, pitch
  from-ref    : reshape an existing reference: --shift 0.85 = bigger/deeper person, 1.2 = smaller/kid-like.
                (moves pitch AND formants, so it sounds like a different person, not the same person pitched)
  from-file   : clone a recording (yours, or one you have permission to use)

usage:
  python3 design_voice.py from-edge  --name "Gruff Narrator" --edge en-US-ChristopherNeural --rate=-5% --pitch=-4Hz --dir Voices
  python3 design_voice.py from-ref   --name "Tiny Hero" --ref Voices/gruff-narrator/ref.wav --shift 1.22 --dir Voices
  python3 design_voice.py from-file  --name "Me" --file my_recording.m4a --dir Voices
  python3 design_voice.py list-edge  [--filter en-]        # list edge-tts voices
(write negative --rate/--pitch with "=", e.g. --rate=-5%, or argparse mistakes them for flags)
Each creates <dir>/<slug>/ref.wav + voice.json (+ sample text). Then make a test line with tts.py --voice <dir>/<slug>/voice.json
"""
import argparse, asyncio, json, os, re, ssl, subprocess, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
SAMPLE = ("Okay, listen closely, because I'm only going to say this once. Last night, something strange happened "
          "in our town. Nobody believed me at first. But then, the lights went out, and everyone heard it too.")

ap = argparse.ArgumentParser()
ap.add_argument("mode", choices=["from-edge", "from-ref", "from-file", "list-edge"])
ap.add_argument("--name"); ap.add_argument("--dir", default="Voices")
ap.add_argument("--edge", default="en-US-ChristopherNeural"); ap.add_argument("--rate", default="+0%"); ap.add_argument("--pitch", default="+0Hz")
ap.add_argument("--text", default=SAMPLE)
ap.add_argument("--ref"); ap.add_argument("--shift", type=float, default=1.0)
ap.add_argument("--file"); ap.add_argument("--start", type=float)
ap.add_argument("--filter", default="en-")
ap.add_argument("--exaggeration", type=float, default=0.5); ap.add_argument("--cfg", type=float, default=0.5)
a = ap.parse_args()

def edge_ssl():
    """edge-tts uses its own SSL context; behind a proxy with a custom CA, point it at the CA bundle."""
    ca = "/root/.ccr/ca-bundle.crt"
    if os.path.exists(ca):
        import edge_tts.communicate as c
        if hasattr(c, "_SSL_CTX"): c._SSL_CTX = ssl.create_default_context(cafile=ca)

if a.mode == "list-edge":
    import edge_tts; edge_ssl()
    vs = asyncio.run(edge_tts.list_voices())
    for v in vs:
        if v["ShortName"].startswith(a.filter):
            tags = ", ".join(v.get("VoiceTag", {}).get("VoicePersonalities", []))
            print(f'{v["ShortName"]:<34} {v["Gender"]:<7} {tags}')
    sys.exit()

if not a.name: sys.exit("--name is required")
slug = re.sub(r"[^a-z0-9]+", "-", a.name.lower()).strip("-")
out = os.path.join(a.dir, slug); os.makedirs(out, exist_ok=True)
raw = tempfile.mktemp(suffix=".wav")
src_note = ""

if a.mode == "from-edge":
    import edge_tts; edge_ssl()
    mp3 = tempfile.mktemp(suffix=".mp3")
    asyncio.run(edge_tts.Communicate(a.text, a.edge, rate=a.rate, pitch=a.pitch).save(mp3))
    subprocess.run(["ffmpeg", "-loglevel", "error", "-y", "-i", mp3, raw], check=True)
    src_note = f"edge-tts {a.edge} rate {a.rate} pitch {a.pitch}"
elif a.mode == "from-ref":
    if not a.ref: sys.exit("--ref is required")
    sr = 24000
    # asetrate moves pitch + formants together (a different-sized speaker); atempo restores the speed
    t = 1 / a.shift; chain = []
    while t > 2: chain.append("atempo=2"); t /= 2
    while t < .5: chain.append("atempo=0.5"); t /= .5
    chain.append(f"atempo={t:.5f}")
    subprocess.run(["ffmpeg", "-loglevel", "error", "-y", "-i", a.ref, "-af", ",".join([f"asetrate={sr}*{a.shift}", f"aresample={sr}", *chain]), raw], check=True)
    src_note = f"reshaped from {a.ref} by {a.shift}"
else:
    if not a.file: sys.exit("--file is required")
    raw = a.file; src_note = f"cloned from {os.path.basename(a.file)}"

ref = os.path.join(out, "ref.wav")
cmd = [sys.executable, "-I", os.path.join(HERE, "make_ref.py"), raw, ref] + (["--start", str(a.start)] if a.start is not None else [])
subprocess.run(cmd, check=True)
voice = {"name": a.name, "ref": "ref.wav", "model": "original", "exaggeration": a.exaggeration, "cfg": a.cfg,
         "temperature": 0.8, "pitch": 1.0, "pitch_mode": "chipmunk", "speed": 1.0, "seed": None, "source": src_note, "notes": ""}
vj = os.path.join(out, "voice.json")
if os.path.exists(vj):   # keep tuned settings when re-making the reference
    old = json.load(open(vj)); voice.update({k: old[k] for k in old if k not in ("ref", "source")})
json.dump(voice, open(vj, "w"), indent=2)
print(f"voice saved: {vj}\nnext: python3 -I {HERE}/tts.py --voice {vj} --text \"Hey, it's me. Does this sound right?\" --out {out}/test")
