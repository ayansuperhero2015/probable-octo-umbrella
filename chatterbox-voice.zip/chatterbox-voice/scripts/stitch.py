#!/usr/bin/env python3
"""Join generated lines into one narration track.
Trims each line's leading/trailing silence and Chatterbox's occasional end-of-line breath/mumble tail,
then joins them with gaps.

usage: python3 stitch.py --lines lines.json --dir segs --out voice_raw.wav [--gap 0.28]
  per-line "gap_before": 0.5 in lines.json overrides the gap (use longer pauses before twists / big moments)
"""
import argparse, json, os
import numpy as np, soundfile as sf

ap = argparse.ArgumentParser()
ap.add_argument("--lines", required=True); ap.add_argument("--dir", required=True); ap.add_argument("--out", required=True)
ap.add_argument("--gap", type=float, default=0.28); ap.add_argument("--thr", type=float, default=0.01)
a = ap.parse_args()

parts, sr0, report = [], None, []
for k, L in enumerate(json.load(open(a.lines))):
    x, sr = sf.read(os.path.join(a.dir, f"{L['id']}.wav"), dtype="float32")
    if x.ndim > 1: x = x.mean(1)
    sr0 = sr0 or sr
    assert sr == sr0, "all lines must share a sample rate"
    loud = np.where(np.abs(x) > a.thr)[0]
    if len(loud):
        i0 = max(0, loud[0] - int(.03 * sr)); i1 = min(len(x), loud[-1] + int(.08 * sr))
        x = x[i0:i1]
    f = int(.006 * sr); x[:f] *= np.linspace(0, 1, f); x[-f:] *= np.linspace(1, 0, f)
    if k: parts.append(np.zeros(int(L.get("gap_before", a.gap) * sr), np.float32))
    start = sum(len(p) for p in parts) / sr
    parts.append(x); report.append((L["id"], round(start, 2), round(start + len(x) / sr, 2)))
y = np.concatenate(parts)
sf.write(a.out, y, sr0)
json.dump([{"id": i, "start": s, "end": e} for i, s, e in report], open(os.path.splitext(a.out)[0] + "_times.json", "w"), indent=1)
print(f"{a.out}: {len(y)/sr0:.1f}s from {len(report)} lines (line start/end times in {os.path.splitext(a.out)[0]}_times.json)")
