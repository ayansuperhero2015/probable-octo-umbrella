#!/usr/bin/env python3
"""Check every generated line: transcribe it with faster-whisper and compare to the script.
Chatterbox sometimes skips, repeats or swaps words ("turns" -> "turned"), or adds mumbling at the end.

usage: python3 check.py --lines lines.json --dir segs [--min 0.90] [--delete-bad]
Prints one row per line: ratio, duration, OK/BAD, and what whisper heard for bad ones.
With --delete-bad, bad wavs are deleted so re-running tts.py regenerates only those.
"""
import argparse, json, os, re, difflib
import numpy as np, soundfile as sf
from faster_whisper import WhisperModel

ap = argparse.ArgumentParser()
ap.add_argument("--lines", required=True); ap.add_argument("--dir", required=True)
ap.add_argument("--min", type=float, default=0.90); ap.add_argument("--delete-bad", action="store_true")
ap.add_argument("--model", default="small.en")
a = ap.parse_args()

def norm(t): return re.sub(r"[^a-z0-9' ]", " ", t.lower()).split()
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))   # works with python3 -I too
from textclean import clean

wm = WhisperModel(a.model, device="cpu", compute_type="int8")
bad = 0
for L in json.load(open(a.lines)):
    p = os.path.join(a.dir, f"{L['id']}.wav")
    if not os.path.exists(p): print(f"{L['id']:>8}  MISSING"); bad += 1; continue
    x, sr = sf.read(p, dtype="float32")
    if x.ndim > 1: x = x.mean(1)
    if sr != 16000:
        import librosa; x = librosa.resample(x, orig_sr=sr, target_sr=16000)
    segs, _ = wm.transcribe(x, language="en", beam_size=5, vad_filter=False)   # no initial_prompt: it causes hallucinations
    heard = " ".join(s.text for s in segs)
    want = clean(L["text"])
    r = difflib.SequenceMatcher(None, norm(want), norm(clean(heard))).ratio()   # whisper writes digits; normalise both sides
    dur = len(x) / 16000
    words = len(norm(want)); wps = words / max(dur, .1)
    flag = "OK" if r >= a.min and 1.2 < wps < 4.5 else "BAD"
    print(f"{L['id']:>8}  {r:.2f}  {dur:5.1f}s  {flag}" + ("" if flag == "OK" else f"   heard: {heard.strip()}"))
    if flag == "BAD":
        bad += 1
        if a.delete_bad: os.remove(p)
print(f"{bad} bad line(s)" + (" deleted: re-run tts.py to regenerate them" if bad and a.delete_bad else ""))
