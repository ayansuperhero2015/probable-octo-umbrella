"""Text fixes for things Chatterbox reads wrong (shared by tts.py and check.py)."""
import re

ONES = "zero one two three four five six seven eight nine ten eleven twelve thirteen fourteen fifteen sixteen seventeen eighteen nineteen".split()
TENS = "_ _ twenty thirty forty fifty sixty seventy eighty ninety".split()
def num(n):
    n = int(n)
    if n < 20: return ONES[n]
    if n < 100: return TENS[n // 10] + ("" if n % 10 == 0 else "-" + ONES[n % 10])
    if n < 1000: return ONES[n // 100] + " hundred" + ("" if n % 100 == 0 else " " + num(n % 100))
    if n < 1_000_000: return num(n // 1000) + " thousand" + ("" if n % 1000 == 0 else " " + num(n % 1000))
    if n < 1_000_000_000: return num(n // 1_000_000) + " million" + ("" if n % 1_000_000 == 0 else " " + num(n % 1_000_000))
    return str(n)

def clean(t):
    """Fixes for things Chatterbox reads wrong."""
    t = t.replace("“", "").replace("”", "").replace('"', "")            # quotes: dialogue still reads naturally
    t = re.sub(r"\$(\d[\d,]*)", lambda m: num(m.group(1).replace(",", "")) + " dollars", t)
    t = re.sub(r"(\d+)%", lambda m: num(m.group(1)) + " percent", t)
    t = re.sub(r"\b(\d{1,2}):(\d{2})\b", lambda m: num(m.group(1)) + ("" if m.group(2) == "00" else " " + num(m.group(2))), t)
    t = re.sub(r"\b\d[\d,]*\b", lambda m: num(m.group(0).replace(",", "")), t)  # numbers as words
    # ALL-CAPS words get spelled out letter by letter ("ONE" -> "O-N-E"): lowercase them (keep I, OK, TV-style acronyms <=2 letters)
    t = re.sub(r"\b[A-Z]{3,}\b", lambda m: m.group(0).lower(), t)
    t = t.replace("&", " and ").replace("...", ", ").replace("…", ", ")
    return " ".join(t.split())
