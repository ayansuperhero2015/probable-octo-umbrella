#!/usr/bin/env python3
"""Final polish: pitch, speed and loudness for a narration track (or a single line).

usage: python3 finish.py in.wav out.wav [--voice voice.json] [--pitch 1.0] [--speed 1.0] [--lufs -14] [--mode chipmunk|keep]
  --pitch 1.12  = 12% higher. Two modes:
     chipmunk (default when pitch != 1): speeds up together with pitch, like a sped-up tape (punchy "Shorts narrator" sound)
     keep: changes pitch only, keeps the timing (uses rubberband if ffmpeg has it, else asetrate+atempo)
  --speed 1.1   = 10% faster without changing pitch (atempo)
  --lufs -14    = YouTube loudness. Use -16 for podcasts, -19 for audiobooks.
"""
import argparse, json, subprocess

ap = argparse.ArgumentParser()
ap.add_argument("src"); ap.add_argument("out"); ap.add_argument("--voice")
ap.add_argument("--pitch", type=float); ap.add_argument("--speed", type=float)
ap.add_argument("--lufs", type=float, default=-14); ap.add_argument("--mode", default=None, choices=[None, "chipmunk", "keep"])
a = ap.parse_args()
V = json.load(open(a.voice)) if a.voice else {}
pitch = a.pitch if a.pitch is not None else V.get("pitch", 1.0)
speed = a.speed if a.speed is not None else V.get("speed", 1.0)
mode = a.mode or V.get("pitch_mode", "chipmunk")

sr = int(subprocess.run(["ffprobe", "-v", "error", "-select_streams", "a:0", "-show_entries", "stream=sample_rate", "-of", "csv=p=0", a.src],
                        capture_output=True, text=True).stdout.strip() or 24000)
def atempo(x):   # atempo accepts 0.5-2.0 per stage
    out = []
    while x > 2: out.append("atempo=2"); x /= 2
    while x < .5: out.append("atempo=0.5"); x /= .5
    out.append(f"atempo={x:.5f}"); return out
f = []
if abs(pitch - 1) > 1e-3:
    if mode == "chipmunk":
        f += [f"asetrate={sr}*{pitch}", f"aresample={sr}"]
    else:
        has_rb = "rubberband" in subprocess.run(["ffmpeg", "-hide_banner", "-filters"], capture_output=True, text=True).stdout
        f += [f"rubberband=pitch={pitch}"] if has_rb else [f"asetrate={sr}*{pitch}", f"aresample={sr}", *atempo(1 / pitch)]
if abs(speed - 1) > 1e-3: f += atempo(speed)
f += [f"loudnorm=I={a.lufs}:TP=-1.5:LRA=11", "aresample=48000"]
subprocess.run(["ffmpeg", "-loglevel", "error", "-y", "-i", a.src, "-af", ",".join(f), "-ar", "48000", a.out], check=True)
print(f"{a.out}  pitch={pitch} ({mode}) speed={speed} loudness={a.lufs} LUFS")
