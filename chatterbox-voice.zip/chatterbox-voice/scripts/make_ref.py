#!/usr/bin/env python3
"""Turn any recording into a clean Chatterbox voice reference (24 kHz mono WAV, ~9 s of speech).

Chatterbox only listens to the first 10 s of a reference (and the first 6 s for speaking style),
so a short, clean, continuous stretch of speech beats a long clip.

usage: python3 make_ref.py input.(mp3|wav|m4a|mp4|...) out_ref.wav [--start SEC] [--len 9]
  --start: where to begin (default: auto-picks the loudest continuous 9 s window with speech)
"""
import argparse, subprocess, sys, tempfile, os
import numpy as np
import soundfile as sf

ap = argparse.ArgumentParser()
ap.add_argument("src"); ap.add_argument("out")
ap.add_argument("--start", type=float, default=None)
ap.add_argument("--len", type=float, default=9.0)
a = ap.parse_args()

tmp = tempfile.mktemp(suffix=".wav")
# mono 24k, cut rumble below 70 Hz, gentle de-hiss above 12 kHz
subprocess.run(["ffmpeg", "-loglevel", "error", "-y", "-i", a.src, "-vn", "-ac", "1", "-ar", "24000",
                "-af", "highpass=f=70,lowpass=f=12000", tmp], check=True)
x, sr = sf.read(tmp); os.remove(tmp)
if x.ndim > 1: x = x.mean(1)
dur = len(x) / sr
if dur < 4: sys.exit(f"Clip is only {dur:.1f}s. Need at least ~5s of clean speech (8-10s is best).")

L = int(min(a.len, dur) * sr)
if a.start is not None:
    s = int(a.start * sr)
else:
    # score each window: speech energy, penalise long silences and clipping
    hop = sr // 10
    rms = np.array([np.sqrt(np.mean(x[i:i + hop] ** 2) + 1e-12) for i in range(0, len(x) - hop, hop)])
    thr = max(np.percentile(rms, 30), 0.01)
    w = L // hop
    best, s = -1e9, 0
    for i in range(0, max(1, len(rms) - w)):
        seg = rms[i:i + w]
        speech = (seg > thr).mean()
        # longest silent run inside the window
        run = m = 0
        for v in seg:
            run = run + 1 if v <= thr else 0; m = max(m, run)
        clip = (np.abs(x[i * hop:i * hop + L]) > 0.99).mean()
        score = speech * 2 - m * 0.08 - clip * 50 + np.log(seg.mean() + 1e-6) * 0.1
        if score > best: best, s = score, i * hop
seg = x[s:s + L]

# trim silence at the edges, keep 50 ms
env = np.abs(seg) > 0.02
if env.any():
    i0 = max(0, np.argmax(env) - int(.05 * sr)); i1 = min(len(seg), len(seg) - np.argmax(env[::-1]) + int(.05 * sr))
    seg = seg[i0:i1]
# peak-normalise to -1 dBFS, short fades
seg = seg / (np.abs(seg).max() + 1e-9) * 0.89
f = int(.01 * sr); seg[:f] *= np.linspace(0, 1, f); seg[-f:] *= np.linspace(1, 0, f)
sf.write(a.out, seg.astype(np.float32), sr)
print(f"ref: {a.out}  {len(seg)/sr:.1f}s  (from {s/sr:.1f}s of {dur:.1f}s source)")
