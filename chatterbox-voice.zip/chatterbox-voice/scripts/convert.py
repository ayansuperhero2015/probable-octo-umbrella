#!/usr/bin/env python3
"""Voice conversion (speech-to-speech): keep the performance of a recording (timing, acting, emphasis)
but make it sound like a saved voice. Good when TTS can't get a line's delivery right: the user records
the line themselves, acting it out, and it comes back in the target voice.

usage: python3 convert.py performance.(wav|mp3|m4a) out.wav (--voice voice.json | --ref ref.wav)
"""
import argparse, json, os, subprocess, tempfile
ap = argparse.ArgumentParser()
ap.add_argument("src"); ap.add_argument("out"); ap.add_argument("--voice"); ap.add_argument("--ref")
a = ap.parse_args()
ref = a.ref
if a.voice:
    V = json.load(open(a.voice)); ref = ref or os.path.join(os.path.dirname(os.path.abspath(a.voice)), V["ref"])
if not ref: raise SystemExit("give --voice or --ref")
wav = tempfile.mktemp(suffix=".wav")
subprocess.run(["ffmpeg", "-loglevel", "error", "-y", "-i", a.src, "-ac", "1", "-ar", "24000", wav], check=True)

import torch, torchaudio as ta
from chatterbox.vc import ChatterboxVC
dev = "cuda" if torch.cuda.is_available() else "cpu"
m = ChatterboxVC.from_pretrained(dev)
y = m.generate(wav, target_voice_path=ref)
ta.save(a.out, y.cpu(), m.sr)
print(f"converted: {a.out}")
