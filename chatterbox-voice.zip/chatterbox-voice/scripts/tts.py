#!/usr/bin/env python3
"""Generate speech with Chatterbox (Resemble AI, open source) on CPU or GPU.

One generation per line -> <out>/<id>.wav. Lines whose file already exists are skipped,
so to redo a bad line just delete its wav and run again. Prints "done <id> <secs>" per line.

usage:
  python3 tts.py --lines lines.json --out segs [--voice voice.json | --ref ref.wav] [--model original|turbo|multilingual]
  python3 tts.py --text "Hello there." --out segs --ref ref.wav
lines.json: [ {"id": "01", "text": "...", "exaggeration": 0.7, "cfg": 0.4, "temperature": 0.8}, ... ]
  (per-line keys are optional; defaults come from voice.json, then the flags)
voice.json (a saved voice): {"name": "...", "ref": "ref.wav", "model": "original", "exaggeration": 0.5, "cfg": 0.5,
                              "temperature": 0.8, "pitch": 1.0, "speed": 1.0, "seed": 0}
Run long jobs in the background:  (setsid nohup python3 -I tts.py ... > gen.log 2>&1 < /dev/null &)
and check progress with:  grep -c ^done gen.log   (don't tail the log: progress bars flood it)
"""
import argparse, json, os, re, sys, time

ap = argparse.ArgumentParser()
ap.add_argument("--lines"); ap.add_argument("--text"); ap.add_argument("--out", required=True)
ap.add_argument("--voice"); ap.add_argument("--ref")
ap.add_argument("--model", default=None, choices=[None, "original", "turbo", "multilingual"])
ap.add_argument("--lang", default="en", help="multilingual model only (en, es, fr, de, it, pt, ja, ko, zh, hi, ar, ...)")
ap.add_argument("--exaggeration", type=float, default=None)
ap.add_argument("--cfg", type=float, default=None)
ap.add_argument("--temperature", type=float, default=None)
ap.add_argument("--seed", type=int, default=None)
ap.add_argument("--device", default=None)
ap.add_argument("--no-clean", action="store_true", help="send text exactly as written")
a = ap.parse_args()

V = {}
if a.voice:
    V = json.load(open(a.voice))
    if V.get("ref") and not os.path.isabs(V["ref"]):
        V["ref"] = os.path.join(os.path.dirname(os.path.abspath(a.voice)), V["ref"])
ref = a.ref or V.get("ref")
model_kind = a.model or V.get("model", "original")
D = {"exaggeration": a.exaggeration if a.exaggeration is not None else V.get("exaggeration", 0.5),
     "cfg": a.cfg if a.cfg is not None else V.get("cfg", 0.5),
     "temperature": a.temperature if a.temperature is not None else V.get("temperature", 0.8)}
seed = a.seed if a.seed is not None else V.get("seed")

if a.lines: lines = json.load(open(a.lines))
elif a.text: lines = [{"id": "line", "text": a.text}]
else: sys.exit("give --lines or --text")
os.makedirs(a.out, exist_ok=True)

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))   # works with python3 -I too
from textclean import clean

import torch, torchaudio as ta
dev = a.device or ("cuda" if torch.cuda.is_available() else "mps" if torch.backends.mps.is_available() else "cpu")
t0 = time.time()
if model_kind == "turbo":
    from chatterbox.tts_turbo import ChatterboxTurboTTS as M
elif model_kind == "multilingual":
    from chatterbox.mtl_tts import ChatterboxMultilingualTTS as M
else:
    from chatterbox.tts import ChatterboxTTS as M
model = M.from_pretrained(device=dev)
print(f"loaded {model_kind} on {dev} in {time.time()-t0:.0f}s", flush=True)
if model_kind == "turbo" and not ref:
    sys.exit("turbo needs a reference voice (--ref or --voice)")

for L in lines:
    out = os.path.join(a.out, f"{L['id']}.wav")
    if os.path.exists(out): print(f"skip {L['id']}", flush=True); continue
    text = L["text"] if a.no_clean else clean(L["text"])
    ex = L.get("exaggeration", D["exaggeration"]); cfg = L.get("cfg", D["cfg"]); temp = L.get("temperature", D["temperature"])
    if seed is not None: torch.manual_seed(seed);
    t1 = time.time()
    kw = dict(audio_prompt_path=ref, temperature=temp)
    if model_kind == "turbo":
        wav = model.generate(text, norm_loudness=False, **kw)   # turbo ignores exaggeration/cfg; its loudness step crashes on CPU (float64 bug), refs from make_ref.py are already normalised
    elif model_kind == "multilingual":
        wav = model.generate(text, language_id=L.get("lang", a.lang), exaggeration=ex, cfg_weight=cfg, **kw)
    else:
        wav = model.generate(text, exaggeration=ex, cfg_weight=cfg, **kw)
    ta.save(out, wav.cpu(), model.sr)
    print(f"done {L['id']} {time.time()-t1:.0f}s  ex={ex} cfg={cfg}  | {text}", flush=True)
print("all done", flush=True)
